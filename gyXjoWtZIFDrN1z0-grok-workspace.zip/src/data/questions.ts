export type QType = "single" | "complex" | "truefalse";

export interface Choice {
  id: string;
  text: string;
}

export interface Statement {
  id: string;
  text: string;
  answer: boolean;
}

export interface Question {
  id: string;
  type: QType;
  topic: string;
  prompt: string;
  choices: Choice[];
  answerIds: string[];
  statements: Statement[];
  discussion: string;
  points?: number;
  level?: "Mudah" | "Sedang" | "Sukar";
  anyOf?: boolean;
  graded?: boolean;
}

export const TYPE_LABEL: Record<QType, string> = {
  single: "Pilihan ganda",
  complex: "Pilihan ganda kompleks",
  truefalse: "Benar / Salah",
};

export const TYPE_SHORT: Record<QType, string> = {
  single: "PG",
  complex: "PGK",
  truefalse: "B/S",
};

export const TYPE_HINT: Record<QType, string> = {
  single: "Pilih satu jawaban yang paling tepat.",
  complex:
    "Pilih semua jawaban yang benar. Soal dinilai benar hanya jika pilihan lengkap dan tidak ada yang salah.",
  truefalse: "Tentukan Benar atau Salah pada pernyataan berikut.",
};

const opts = (lines: string[]): Choice[] =>
  lines.map((text, i) => ({ id: "abcde"[i] ?? String(i), text }));

function pg(partial: {
  id: string;
  topic: string;
  prompt: string;
  options: string[];
  answer: string;
  discussion: string;
}): Question {
  return {
    id: partial.id,
    type: "single",
    topic: partial.topic,
    level: "Mudah",
    points: 4,
    prompt: partial.prompt,
    choices: opts(partial.options),
    answerIds: [partial.answer],
    statements: [],
    discussion: partial.discussion,
  };
}

function pgk(partial: {
  id: string;
  topic: string;
  prompt: string;
  options: string[];
  answer: string[];
  discussion: string;
}): Question {
  return {
    id: partial.id,
    type: "complex",
    topic: partial.topic,
    level: "Sedang",
    points: 4,
    prompt: partial.prompt,
    choices: opts(partial.options),
    answerIds: partial.answer,
    statements: [],
    discussion: partial.discussion,
  };
}

function bs(partial: {
  id: string;
  topic: string;
  statement: string;
  answer: boolean;
  discussion: string;
}): Question {
  return {
    id: partial.id,
    type: "truefalse",
    topic: partial.topic,
    level: "Mudah",
    points: 4,
    prompt: "Tentukan benar atau salah pernyataan berikut.",
    choices: [],
    answerIds: [],
    statements: [{ id: "s1", text: partial.statement, answer: partial.answer }],
    discussion: partial.discussion,
  };
}

export const BANK: Question[] = [
  pg({
    id: "p01",
    topic: "Dasar negara",
    prompt: "Dasar negara Indonesia adalah …",
    options: ["UUD 1945", "Pancasila", "Bhinneka Tunggal Ika", "Sumpah Pemuda"],
    answer: "b",
    discussion: "Kunci: B. Dasar negara Indonesia adalah Pancasila.",
  }),
  pg({
    id: "p02",
    topic: "Pancasila",
    prompt: "Sila pertama Pancasila berbunyi …",
    options: [
      "Kemanusiaan yang adil dan beradab",
      "Persatuan Indonesia",
      "Ketuhanan Yang Maha Esa",
      "Kerakyatan yang dipimpin oleh hikmat kebijaksanaan dalam permusyawaratan/perwakilan",
    ],
    answer: "c",
    discussion: "Kunci: C. Sila pertama adalah Ketuhanan Yang Maha Esa.",
  }),
  pg({
    id: "p03",
    topic: "Bhinneka Tunggal Ika",
    prompt: "Makna Bhinneka Tunggal Ika adalah …",
    options: [
      "Berbeda-beda tetapi tetap satu",
      "Bersatu kita teguh",
      "Satu nusa satu bangsa",
      "Hidup rukun dan damai",
    ],
    answer: "a",
    discussion: "Kunci: A. Bhinneka Tunggal Ika berarti berbeda-beda tetapi tetap satu.",
  }),
  pg({
    id: "p04",
    topic: "Pemerintahan",
    prompt: "Sistem pemerintahan Indonesia berdasarkan UUD 1945 adalah …",
    options: ["Presidensial", "Parlementer", "Monarki", "Federasi"],
    answer: "a",
    discussion: "Kunci: A. Indonesia menganut sistem pemerintahan presidensial.",
  }),
  pg({
    id: "p05",
    topic: "Sejarah",
    prompt: "Sumpah Pemuda digelar pada tanggal …",
    options: ["17 Agustus 1945", "28 Oktober 1928", "1 Juni 1945", "20 Mei 1908"],
    answer: "b",
    discussion: "Kunci: B. Sumpah Pemuda dikumandangkan pada 28 Oktober 1928.",
  }),
  pg({
    id: "p06",
    topic: "Pancasila",
    prompt: "Contoh sikap yang sesuai dengan sila kedua Pancasila adalah …",
    options: [
      "Menghormati orang yang berbeda agama",
      "Menghargai hak orang lain",
      "Mengutamakan kepentingan bangsa",
      "Bermusyawarah dalam mengambil keputusan",
    ],
    answer: "b",
    discussion:
      "Kunci: B. Sila kedua, Kemanusiaan yang adil dan beradab, tercermin pada sikap menghargai hak orang lain.",
  }),
  bs({
    id: "p07",
    topic: "Pancasila",
    statement: "Pancasila terdiri dari lima sila.",
    answer: true,
    discussion: "Kunci: Benar. Pancasila terdiri dari lima sila.",
  }),
  bs({
    id: "p08",
    topic: "UUD 1945",
    statement: "UUD 1945 merupakan hukum dasar tertulis di Indonesia.",
    answer: true,
    discussion: "Kunci: Benar. UUD 1945 adalah hukum dasar tertulis.",
  }),
  bs({
    id: "p09",
    topic: "Hak warga negara",
    statement: "Setiap warga negara berhak mendapatkan pendidikan.",
    answer: true,
    discussion: "Kunci: Benar. Pendidikan adalah hak setiap warga negara.",
  }),
  bs({
    id: "p10",
    topic: "Toleransi",
    statement: "Toleransi hanya berlaku untuk perbedaan agama saja.",
    answer: false,
    discussion:
      "Kunci: Salah. Toleransi berlaku untuk berbagai perbedaan, bukan hanya agama.",
  }),
  bs({
    id: "p11",
    topic: "Demokrasi",
    statement: "Presiden dipilih melalui pemilihan umum secara langsung.",
    answer: true,
    discussion: "Kunci: Benar. Presiden dan wakil presiden dipilih langsung oleh rakyat.",
  }),
  bs({
    id: "p12",
    topic: "Persatuan",
    statement: "Menjaga persatuan dan kesatuan bangsa merupakan kewajiban setiap warga negara.",
    answer: true,
    discussion: "Kunci: Benar. Menjaga persatuan dan kesatuan adalah kewajiban warga negara.",
  }),
  pgk({
    id: "p13",
    topic: "Pancasila",
    prompt: "Manakah yang termasuk sila-sila Pancasila?",
    options: [
      "Ketuhanan Yang Maha Esa",
      "Kemanusiaan yang adil dan beradab",
      "Persatuan Indonesia",
      "Kerakyatan yang dipimpin oleh hikmat kebijaksanaan dalam permusyawaratan/perwakilan",
      "Keadilan sosial bagi seluruh rakyat Indonesia",
    ],
    answer: ["a", "b", "c", "d", "e"],
    discussion: "Kunci: A, B, C, D, dan E. Kelimanya adalah sila Pancasila.",
  }),
  pgk({
    id: "p14",
    topic: "Kewajiban",
    prompt: "Manakah yang termasuk kewajiban warga negara Indonesia?",
    options: [
      "Membayar pajak",
      "Menjaga nama baik bangsa",
      "Membela negara",
      "Mengikuti pemilu",
      "Menuntut ilmu",
    ],
    answer: ["a", "b", "c"],
    discussion:
      "Kunci: A, B, dan C. Membayar pajak, menjaga nama baik bangsa, dan membela negara termasuk kewajiban warga negara.",
  }),
  pgk({
    id: "p15",
    topic: "Bhinneka Tunggal Ika",
    prompt: "Manakah pernyataan yang benar tentang Bhinneka Tunggal Ika?",
    options: [
      "Merupakan semboyan negara Indonesia",
      "Berarti berbeda-beda tetapi tetap satu",
      "Tercantum pada kaki Garuda Pancasila",
      "Hanya berlaku untuk perbedaan agama",
      "Mendorong sikap toleransi",
    ],
    answer: ["a", "b", "c", "e"],
    discussion:
      "Kunci: A, B, C, dan E. Bhinneka Tunggal Ika bukan hanya untuk perbedaan agama.",
  }),
  pgk({
    id: "p16",
    topic: "Hak warga negara",
    prompt: "Manakah yang termasuk hak warga negara?",
    options: [
      "Hak untuk hidup",
      "Hak mendapatkan pendidikan",
      "Hak memilih dan dipilih",
      "Hak mengeluarkan pendapat",
      "Hak untuk tidak membayar pajak",
    ],
    answer: ["a", "b", "c", "d"],
    discussion:
      "Kunci: A, B, C, dan D. Tidak membayar pajak bukan hak warga negara.",
  }),
  pgk({
    id: "p17",
    topic: "Pancasila",
    prompt: "Manakah sikap yang sesuai dengan nilai-nilai Pancasila?",
    options: [
      "Menghormati orang yang berbeda agama",
      "Mengutamakan kepentingan pribadi",
      "Bermusyawarah dalam mengambil keputusan",
      "Menghargai perbedaan suku dan budaya",
      "Memaksakan kehendak kepada orang lain",
    ],
    answer: ["a", "c", "d"],
    discussion:
      "Kunci: A, C, dan D. Mengutamakan kepentingan pribadi dan memaksakan kehendak tidak sesuai Pancasila.",
  }),
  pgk({
    id: "p18",
    topic: "Demokrasi",
    prompt: "Manakah yang termasuk contoh pelaksanaan demokrasi di sekolah?",
    options: [
      "Memilih ketua kelas secara musyawarah",
      "Mengemukakan pendapat saat diskusi",
      "Mematuhi tata tertib sekolah",
      "Menghargai perbedaan pendapat teman",
      "Membuat gaduh saat ada yang berpendapat berbeda",
    ],
    answer: ["a", "b", "d"],
    discussion:
      "Kunci: A, B, dan D. Mematuhi tata tertib adalah kedisiplinan, dan membuat gaduh bukan sikap demokratis.",
  }),
  pgk({
    id: "p19",
    topic: "UUD 1945",
    prompt: "Manakah pernyataan yang benar tentang UUD 1945?",
    options: [
      "Merupakan hukum dasar negara Indonesia",
      "Menjadi sumber dari segala sumber hukum",
      "Bisa diubah melalui amandemen",
      "Hanya berlaku untuk orang dewasa",
      "Mengatur hak dan kewajiban warga negara",
    ],
    answer: ["a", "b", "c", "e"],
    discussion:
      "Kunci: A, B, C, dan E. UUD 1945 berlaku bagi seluruh warga negara, bukan hanya orang dewasa.",
  }),
  pgk({
    id: "p20",
    topic: "Toleransi",
    prompt: "Manakah yang termasuk contoh sikap toleransi?",
    options: [
      "Menghormati teman yang berbeda agama",
      "Tidak memaksakan kehendak kepada orang lain",
      "Menghargai perbedaan pendapat",
      "Mengolok-olok teman yang berbeda suku",
      "Membantu teman meski berbeda keyakinan",
    ],
    answer: ["a", "b", "c", "e"],
    discussion: "Kunci: A, B, C, dan E. Mengolok-olok perbedaan bukan sikap toleransi.",
  }),
  pg({
    id: "p21",
    topic: "Lembaga negara",
    prompt: "Lembaga tertinggi negara menurut UUD 1945 setelah amandemen adalah …",
    options: ["MPR", "DPR", "Presiden", "Mahkamah Agung"],
    answer: "a",
    discussion: "Kunci: A. Menurut kunci soal ini, jawabannya adalah MPR.",
  }),
  pg({
    id: "p22",
    topic: "Sejarah",
    prompt: "Arti penting Sumpah Pemuda bagi bangsa Indonesia adalah …",
    options: [
      "Menjadi dasar pembentukan negara",
      "Menumbuhkan semangat persatuan dan kesatuan",
      "Menjadi dasar hukum negara",
      "Menjadi lambang negara",
    ],
    answer: "b",
    discussion:
      "Kunci: B. Sumpah Pemuda menumbuhkan semangat persatuan dan kesatuan bangsa.",
  }),
  pg({
    id: "p23",
    topic: "Persatuan",
    prompt: "Sikap yang mencerminkan nilai persatuan Indonesia adalah …",
    options: [
      "Mengutamakan kepentingan golongan",
      "Menghargai perbedaan suku dan budaya",
      "Memaksakan kehendak kepada orang lain",
      "Memisahkan diri dari kelompok masyarakat",
    ],
    answer: "b",
    discussion: "Kunci: B. Menghargai perbedaan suku dan budaya mencerminkan persatuan.",
  }),
  pg({
    id: "p24",
    topic: "Hak asasi",
    prompt: "Salah satu contoh pelaksanaan hak asasi manusia di sekolah adalah …",
    options: [
      "Membolos saat pelajaran berlangsung",
      "Mengikuti upacara bendera dengan tertib",
      "Mendapatkan perlakuan yang sama dari guru",
      "Membuat gaduh di dalam kelas",
    ],
    answer: "c",
    discussion:
      "Kunci: C. Perlakuan yang sama dari guru adalah pelaksanaan hak asasi di sekolah.",
  }),
  pg({
    id: "p25",
    topic: "Kewajiban",
    prompt: "Kewajiban warga negara terhadap negara di antaranya adalah …",
    options: [
      "Membayar pajak",
      "Menuntut ilmu sebanyak-banyaknya",
      "Menuntut hak secara sepihak",
      "Menolak peraturan yang tidak disukai",
    ],
    answer: "a",
    discussion: "Kunci: A. Membayar pajak adalah kewajiban warga negara terhadap negara.",
  }),
];
