import { create } from "zustand";
import { persist } from "zustand/middleware";
import { BANK, type QType, type Question } from "@/data/questions";
import { shuffle, type Answer } from "@/lib/quiz/scoring";

export interface Settings {
  title: string;
  description: string;
  durationMin: number;
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
}

export interface Session {
  phase: "ready" | "running" | "result" | "review";
  studentName: string;
  paper: Question[];
  index: number;
  answers: Record<string, Answer>;
  flags: string[];
  startedAt: number | null;
  endsAt: number | null;
  submittedAt: number | null;
  expired: boolean;
}

export const defaultSettings: Settings = {
  title: "Latihan PKN",
  description: "25 soal Pendidikan Kewarganegaraan: pilihan ganda, benar-salah, dan pilihan ganda kompleks. Setiap soal 4 poin.",
  durationMin: 60,
  shuffleQuestions: false,
  shuffleOptions: false,
};

function emptySession(name = ""): Session {
  return {
    phase: "ready",
    studentName: name,
    paper: [],
    index: 0,
    answers: {},
    flags: [],
    startedAt: null,
    endsAt: null,
    submittedAt: null,
    expired: false,
  };
}

interface QuizState {
  screen: "exam" | "builder";
  settings: Settings;
  overrides: Record<string, Question>;
  hidden: string[];
  custom: Question[];
  session: Session;
  setScreen: (screen: "exam" | "builder") => void;
  setStudentName: (name: string) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  start: () => void;
  abandon: () => void;
  submit: (expired?: boolean) => void;
  toReview: () => void;
  toResults: () => void;
  goTo: (index: number) => void;
  toggleFlag: (id: string) => void;
  pickChoice: (qid: string, choiceId: string, type: QType) => void;
  pickTf: (qid: string, statementId: string, value: boolean) => void;
  saveQuestion: (q: Question) => void;
  deleteQuestion: (id: string) => void;
  resetBank: () => void;
  clearCustom: () => void;
  importBundle: (bundle: Persisted) => void;
}

export interface Persisted {
  screen: "exam" | "builder";
  settings: Settings;
  overrides: Record<string, Question>;
  hidden: string[];
  custom: Question[];
  session: Session;
}

function clampMin(n: number) {
  if (!Number.isFinite(n)) return defaultSettings.durationMin;
  return Math.min(180, Math.max(1, Math.round(n)));
}

export function activeQuestions(s: Pick<QuizState, "overrides" | "hidden" | "custom">): Question[] {
  const hidden = new Set(s.hidden);
  const bank = BANK.filter((q) => !hidden.has(q.id)).map((q) => s.overrides[q.id] ?? q);
  return [...bank, ...s.custom];
}

export function isBankId(id: string) {
  return BANK.some((q) => q.id === id);
}

export const useQuizStore = create<QuizState>()(
  persist(
    (set, get) => ({
      screen: "exam",
      settings: defaultSettings,
      overrides: {},
      hidden: [],
      custom: [],
      session: emptySession(),
      setScreen: (screen) => set({ screen }),
      setStudentName: (name) =>
        set((s) => ({ session: { ...s.session, studentName: name.slice(0, 40) } })),
      updateSettings: (patch) =>
        set((s) => ({
          settings: {
            ...s.settings,
            ...patch,
            durationMin: clampMin(patch.durationMin ?? s.settings.durationMin),
            title: (patch.title ?? s.settings.title).slice(0, 120),
            description: (patch.description ?? s.settings.description).slice(0, 240),
          },
        })),
      start: () => {
        const s = get();
        const source = activeQuestions(s);
        if (source.length === 0) return;
        let paper = source.map((q) => structuredClone(q));
        if (s.settings.shuffleQuestions) paper = shuffle(paper);
        if (s.settings.shuffleOptions) {
          paper = paper.map((q) =>
            q.type === "truefalse" ? q : { ...q, choices: shuffle(q.choices) },
          );
        }
        const now = Date.now();
        set({
          screen: "exam",
          session: {
            phase: "running",
            studentName: s.session.studentName.trim(),
            paper,
            index: 0,
            answers: {},
            flags: [],
            startedAt: now,
            endsAt: now + clampMin(s.settings.durationMin) * 60 * 1000,
            submittedAt: null,
            expired: false,
          },
        });
      },
      abandon: () => set((s) => ({ session: emptySession(s.session.studentName) })),
      submit: (expired = false) =>
        set((s) => {
          if (s.session.phase !== "running") return s;
          const now = Date.now();
          return {
            session: {
              ...s.session,
              phase: "result",
              submittedAt: now,
              expired: expired || (s.session.endsAt != null && now >= s.session.endsAt),
            },
          };
        }),
      toReview: () =>
        set((s) => ({
          screen: "exam",
          session: { ...s.session, phase: "review", index: 0 },
        })),
      toResults: () =>
        set((s) =>
          s.session.submittedAt ? { session: { ...s.session, phase: "result" } } : s,
        ),
      goTo: (index) =>
        set((s) => {
          const max = s.session.paper.length - 1;
          if (max < 0) return s;
          return { session: { ...s.session, index: Math.min(max, Math.max(0, index)) } };
        }),
      toggleFlag: (id) =>
        set((s) => {
          if (s.session.phase !== "running") return s;
          const has = s.session.flags.includes(id);
          return {
            session: {
              ...s.session,
              flags: has ? s.session.flags.filter((f) => f !== id) : [...s.session.flags, id],
            },
          };
        }),
      pickChoice: (qid, choiceId, type) =>
        set((s) => {
          if (s.session.phase !== "running") return s;
          const prev = s.session.answers[qid];
          const ids = prev?.kind === "choice" ? prev.ids : [];
          let next: string[];
          if (type === "single") next = ids.length === 1 && ids[0] === choiceId ? [] : [choiceId];
          else next = ids.includes(choiceId) ? ids.filter((id) => id !== choiceId) : [...ids, choiceId];
          return {
            session: {
              ...s.session,
              answers: { ...s.session.answers, [qid]: { kind: "choice", ids: next } },
            },
          };
        }),
      pickTf: (qid, statementId, value) =>
        set((s) => {
          if (s.session.phase !== "running") return s;
          const prev = s.session.answers[qid];
          const values = prev?.kind === "tf" ? { ...prev.values } : {};
          if (values[statementId] === value) delete values[statementId];
          else values[statementId] = value;
          return {
            session: {
              ...s.session,
              answers: { ...s.session.answers, [qid]: { kind: "tf", values } },
            },
          };
        }),
      saveQuestion: (q) =>
        set((s) => {
          if (isBankId(q.id)) return { overrides: { ...s.overrides, [q.id]: q } };
          const idx = s.custom.findIndex((c) => c.id === q.id);
          if (idx >= 0) {
            const custom = s.custom.slice();
            custom[idx] = q;
            return { custom };
          }
          return { custom: [...s.custom, q] };
        }),
      deleteQuestion: (id) =>
        set((s) => {
          if (isBankId(id)) {
            const overrides = { ...s.overrides };
            delete overrides[id];
            return {
              overrides,
              hidden: s.hidden.includes(id) ? s.hidden : [...s.hidden, id],
            };
          }
          return { custom: s.custom.filter((c) => c.id !== id) };
        }),
      resetBank: () => set({ hidden: [], overrides: {} }),
      clearCustom: () => set({ custom: [] }),
      importBundle: (bundle) =>
        set(() => ({
          settings: {
            ...defaultSettings,
            ...bundle.settings,
            durationMin: clampMin(bundle.settings?.durationMin ?? defaultSettings.durationMin),
          },
          overrides: bundle.overrides ?? {},
          hidden: bundle.hidden ?? [],
          custom: bundle.custom ?? [],
        })),
    }),
    {
      name: "pkn-quiz-v1",
      skipHydration: true,
      partialize: (s) => ({
        screen: s.screen,
        settings: s.settings,
        overrides: s.overrides,
        hidden: s.hidden,
        custom: s.custom,
        session: s.session,
      }),
    },
  ),
);
