import type { Question } from "@/data/questions";

export type ChoiceAnswer = { kind: "choice"; ids: string[] };
export type TfAnswer = { kind: "tf"; values: Record<string, boolean> };
export type Answer = ChoiceAnswer | TfAnswer;

export function isAnswered(q: Question, answer: Answer | undefined): boolean {
  if (!answer) return false;
  if (q.type === "truefalse") {
    if (answer.kind !== "tf") return false;
    return q.statements.every((s) => typeof answer.values[s.id] === "boolean");
  }
  return answer.kind === "choice" && answer.ids.length > 0;
}

export function isCorrect(q: Question, answer: Answer | undefined): boolean {
  if (q.graded === false) return false;
  if (!isAnswered(q, answer) || !answer) return false;
  if (q.type === "truefalse") {
    if (answer.kind !== "tf") return false;
    return q.statements.every((s) => answer.values[s.id] === s.answer);
  }
  if (answer.kind !== "choice") return false;
  if (q.anyOf) return answer.ids.length === 1 && q.answerIds.includes(answer.ids[0] ?? "");
  const want = [...q.answerIds].sort();
  const got = [...answer.ids].sort();
  if (want.length !== got.length) return false;
  return want.every((id, i) => id === got[i]);
}

export function scorePaper(paper: Question[], answers: Record<string, Answer>) {
  let earned = 0;
  let max = 0;
  let correct = 0;
  let wrong = 0;
  for (const q of paper) {
    if (q.graded === false) continue;
    const pts = q.points ?? 1;
    max += pts;
    if (isCorrect(q, answers[q.id])) {
      earned += pts;
      correct += 1;
    } else wrong += 1;
  }
  const total = correct + wrong;
  const percent = max === 0 ? 0 : Math.round((earned / max) * 100);
  return { correct, wrong, total, percent, earned, max };
}

export function breakdown(
  paper: Question[],
  answers: Record<string, Answer>,
  keyOf: (q: Question) => string,
) {
  const order: string[] = [];
  const map = new Map<string, { correct: number; total: number }>();
  for (const q of paper) {
    if (q.graded === false) continue;
    const key = keyOf(q);
    if (!map.has(key)) {
      map.set(key, { correct: 0, total: 0 });
      order.push(key);
    }
    const row = map.get(key)!;
    row.total += 1;
    if (isCorrect(q, answers[q.id])) row.correct += 1;
  }
  return order.map((key) => ({ key, ...map.get(key)! }));
}

export function formatClock(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}

export function formatSpent(ms: number): string {
  const s = Math.max(0, Math.round(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  if (m <= 0) return `${r} detik`;
  return `${m} menit ${r} detik`;
}

export function shuffle<T>(list: readonly T[]): T[] {
  const arr = list.slice();
  for (let i = arr.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = arr[i]!;
    arr[i] = arr[j]!;
    arr[j] = tmp;
  }
  return arr;
}
