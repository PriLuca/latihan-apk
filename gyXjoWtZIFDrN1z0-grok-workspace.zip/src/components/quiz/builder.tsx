import type { ReactNode } from "react";
import { Download, Pencil, Plus, RotateCcw, Trash2, Upload, X } from "lucide-react";
import { useRef, useState } from "react";
import { BANK, TYPE_LABEL, TYPE_SHORT, type Choice, type QType, type Question, type Statement } from "@/data/questions";
import { cn } from "@/lib/cn";
import { activeQuestions, isBankId, useQuizStore, type Persisted } from "@/lib/quiz/store";

const field =
  "w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink placeholder:text-muted";

function blank(type: QType): Question {
  const id = `c_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
  if (type === "truefalse") {
    return {
      id,
      type,
      topic: "",
      prompt: "",
      discussion: "",
      choices: [],
      answerIds: [],
      statements: [
        { id: "s1", text: "", answer: true },
        { id: "s2", text: "", answer: false },
      ],
    };
  }
  return {
    id,
    type,
    topic: "",
    prompt: "",
    discussion: "",
    statements: [],
    answerIds: ["a"],
    choices: [
      { id: "a", text: "" },
      { id: "b", text: "" },
      { id: "c", text: "" },
      { id: "d", text: "" },
    ],
  };
}

function clean(q: Question): Question | string {
  const topic = q.topic.trim();
  const prompt = q.prompt.trim();
  const discussion = q.discussion.trim();
  if (topic.length < 2) return "Topik minimal 2 karakter.";
  if (prompt.length < 10) return "Pertanyaan minimal 10 karakter.";
  if (discussion.length < 10) return "Pembahasan minimal 10 karakter.";
  if (q.type === "truefalse") {
    const statements = q.statements
      .map((s) => ({ ...s, text: s.text.trim() }))
      .filter((s) => s.text)
      .slice(0, 6);
    if (statements.length < 2) return "Isi minimal dua pernyataan.";
    return { ...q, topic, prompt, discussion, choices: [], answerIds: [], statements };
  }
  const choices = q.choices
    .map((c) => ({ ...c, text: c.text.trim() }))
    .filter((c) => c.text)
    .slice(0, 8);
  if (choices.length < 2) return "Isi minimal dua pilihan.";
  const ids = new Set(choices.map((c) => c.id));
  const answerIds = q.answerIds.filter((id) => ids.has(id));
  if (q.type === "single" && answerIds.length !== 1) return "Tandai tepat satu kunci jawaban.";
  if (q.type === "complex" && answerIds.length < 1) return "Tandai minimal satu kunci jawaban.";
  return { ...q, topic, prompt, discussion, choices, answerIds, statements: [] };
}

function isQuestion(value: unknown): value is Question {
  if (!value || typeof value !== "object") return false;
  const q = value as Question;
  if (
    typeof q.id !== "string" ||
    (q.type !== "single" && q.type !== "complex" && q.type !== "truefalse") ||
    typeof q.prompt !== "string" ||
    typeof q.topic !== "string" ||
    typeof q.discussion !== "string" ||
    !Array.isArray(q.choices) ||
    !Array.isArray(q.answerIds) ||
    !Array.isArray(q.statements)
  ) {
    return false;
  }
  const choicesOk = q.choices.every(
    (c) => !!c && typeof c.id === "string" && typeof c.text === "string",
  );
  const statementsOk = q.statements.every(
    (s) => !!s && typeof s.id === "string" && typeof s.text === "string" && typeof s.answer === "boolean",
  );
  return choicesOk && statementsOk && q.answerIds.every((id) => typeof id === "string");
}

export function BuilderView() {
  const settings = useQuizStore((s) => s.settings);
  const updateSettings = useQuizStore((s) => s.updateSettings);
  const overrides = useQuizStore((s) => s.overrides);
  const hidden = useQuizStore((s) => s.hidden);
  const custom = useQuizStore((s) => s.custom);
  const saveQuestion = useQuizStore((s) => s.saveQuestion);
  const deleteQuestion = useQuizStore((s) => s.deleteQuestion);
  const resetBank = useQuizStore((s) => s.resetBank);
  const clearCustom = useQuizStore((s) => s.clearCustom);
  const importBundle = useQuizStore((s) => s.importBundle);
  const running = useQuizStore((s) => s.session.phase === "running");
  const questions = activeQuestions({ overrides, hidden, custom });
  const [filter, setFilter] = useState<"all" | QType | "custom">("all");
  const [query, setQuery] = useState("");
  const [draft, setDraft] = useState<Question | null>(null);
  const [error, setError] = useState("");
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [notice, setNotice] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const shown = questions.filter((q) => {
    if (filter === "custom" && isBankId(q.id)) return false;
    if (filter !== "all" && filter !== "custom" && q.type !== filter) return false;
    const hay = `${q.topic} ${q.prompt}`.toLowerCase();
    return hay.includes(query.trim().toLowerCase());
  });

  function openNew() {
    setError("");
    setDraft(blank("single"));
  }

  function openEdit(q: Question) {
    setError("");
    setDraft(structuredClone(q));
  }

  function save() {
    if (!draft) return;
    const result = clean(draft);
    if (typeof result === "string") {
      setError(result);
      return;
    }
    saveQuestion(result);
    setDraft(null);
    setNotice("Soal tersimpan di perangkat ini.");
  }

  function exportBank() {
    const safe = { version: 1, settings, overrides, hidden, custom };
    const blob = new Blob([JSON.stringify(safe, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "bank-soal-notula.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  async function onImport(file: File) {
    try {
      const raw = JSON.parse(await file.text()) as {
        settings?: Persisted["settings"];
        overrides?: Record<string, unknown>;
        hidden?: unknown;
        custom?: unknown;
      };
      const bankIds = new Set(BANK.map((q) => q.id));
      const overridesNext: Record<string, Question> = {};
      if (raw.overrides && typeof raw.overrides === "object") {
        for (const [id, value] of Object.entries(raw.overrides)) {
          if (bankIds.has(id) && isQuestion(value)) overridesNext[id] = value;
        }
      }
      const hiddenNext = Array.isArray(raw.hidden)
        ? raw.hidden.filter((id): id is string => typeof id === "string" && bankIds.has(id))
        : [];
      const customNext: Question[] = [];
      if (Array.isArray(raw.custom)) {
        for (const value of raw.custom) {
          if (!isQuestion(value)) continue;
          const id = bankIds.has(value.id) ? `c_${value.id}_${customNext.length}` : value.id;
          customNext.push({ ...value, id });
        }
      }
      importBundle({
        screen: "builder",
        settings: { ...settings, ...(raw.settings ?? {}) },
        overrides: overridesNext,
        hidden: hiddenNext,
        custom: customNext,
        session: useQuizStore.getState().session,
      });
      setNotice(`Berkas masuk: ${Object.keys(overridesNext).length} suntingan, ${customNext.length} soal buatan.`);
    } catch {
      setNotice("Berkas tidak bisa dibaca. Gunakan ekspor dari aplikasi ini.");
    }
  }

  return (
    <div className="space-y-6">
      {running && (
        <p className="rounded-xl border border-gold bg-gold-soft px-4 py-3 text-sm text-ink">
          Ujian sedang berlangsung. Perubahan soal tidak mengubah naskah percobaan yang sudah dimulai.
        </p>
      )}
      <section className="rounded-2xl border border-line bg-surface p-5 shadow-sm sm:p-6">
        <h2 className="font-display text-2xl font-semibold">Pengaturan ujian</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <label className="block text-sm font-medium sm:col-span-2">
            Judul
            <input
              className={cn(field, "mt-1")}
              value={settings.title}
              onChange={(e) => updateSettings({ title: e.target.value })}
            />
          </label>
          <label className="block text-sm font-medium sm:col-span-2">
            Deskripsi
            <input
              className={cn(field, "mt-1")}
              value={settings.description}
              onChange={(e) => updateSettings({ description: e.target.value })}
            />
          </label>
          <label className="block text-sm font-medium">
            Durasi (menit)
            <input
              type="number"
              min={1}
              max={180}
              className={cn(field, "mt-1")}
              value={settings.durationMin}
              onChange={(e) => updateSettings({ durationMin: Number(e.target.value) })}
            />
          </label>
          <div className="flex flex-col justify-end gap-2 text-sm">
            <Toggle
              on={settings.shuffleQuestions}
              label="Acak urutan soal"
              onClick={() => updateSettings({ shuffleQuestions: !settings.shuffleQuestions })}
            />
            <Toggle
              on={settings.shuffleOptions}
              label="Acak urutan pilihan"
              onClick={() => updateSettings({ shuffleOptions: !settings.shuffleOptions })}
            />
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-line bg-surface p-5 shadow-sm sm:p-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-2xl font-semibold">Bank soal</h2>
            <p className="text-sm text-muted">
              {questions.length} soal aktif
              {hidden.length > 0 ? ` · ${hidden.length} bawaan disembunyikan` : ""}
              {custom.length > 0 ? ` · ${custom.length} buatan` : ""}
            </p>
          </div>
          <button
            type="button"
            onClick={openNew}
            className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-ink"
          >
            <Plus className="size-4" />
            Tambah soal
          </button>
        </div>
        <div className="mt-4 flex flex-col gap-3 sm:flex-row">
          <input
            className={field}
            placeholder="Cari topik atau potongan soal"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <div className="flex flex-wrap gap-2">
            {(
              [
                ["all", "Semua"],
                ["single", "PG"],
                ["complex", "PGK"],
                ["truefalse", "B/S"],
                ["custom", "Buatan"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setFilter(id)}
                className={cn(
                  "min-h-11 rounded-full px-3 text-sm font-medium",
                  filter === id ? "bg-primary text-primary-ink" : "bg-bg text-ink",
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        {notice && <p className="mt-3 text-sm text-ok">{notice}</p>}
        <ul className="mt-4 divide-y divide-line">
          {shown.map((q, i) => (
            <li key={q.id} className="flex items-start gap-3 py-3">
              <span className="mt-0.5 w-8 shrink-0 text-sm font-semibold text-muted">{i + 1}</span>
              <div className="min-w-0 flex-1">
                <div className="mb-1 flex flex-wrap gap-2">
                  <span className="rounded-full bg-primary-soft px-2 py-0.5 text-xs font-semibold text-primary">
                    {TYPE_SHORT[q.type]}
                  </span>
                  <span className="rounded-full bg-gold-soft px-2 py-0.5 text-xs font-semibold text-gold">
                    {q.topic}
                  </span>
                  {!isBankId(q.id) && (
                    <span className="rounded-full bg-bg px-2 py-0.5 text-xs font-semibold text-muted">Buatan</span>
                  )}
                  {overrides[q.id] && (
                    <span className="rounded-full bg-bg px-2 py-0.5 text-xs font-semibold text-muted">Diedit</span>
                  )}
                </div>
                <p className="line-clamp-2 text-sm leading-relaxed">{q.prompt}</p>
              </div>
              <div className="flex shrink-0 gap-1">
                <IconButton label="Sunting soal" onClick={() => openEdit(q)}>
                  <Pencil className="size-4" />
                </IconButton>
                <IconButton label="Hapus soal" onClick={() => setPendingDelete(q.id)}>
                  <Trash2 className="size-4" />
                </IconButton>
              </div>
            </li>
          ))}
          {shown.length === 0 && <li className="py-8 text-center text-sm text-muted">Tidak ada soal pada saringan ini.</li>}
        </ul>
        <div className="mt-4 flex flex-wrap gap-2 border-t border-line pt-4">
          <button type="button" onClick={exportBank} className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-bg px-3 text-sm font-medium">
            <Download className="size-4" />
            Ekspor
          </button>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-bg px-3 text-sm font-medium"
          >
            <Upload className="size-4" />
            Impor
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void onImport(file);
              e.target.value = "";
            }}
          />
          <button
            type="button"
            onClick={() => {
              resetBank();
              setNotice("Soal bawaan dikembalikan.");
            }}
            className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-bg px-3 text-sm font-medium"
          >
            <RotateCcw className="size-4" />
            Pulihkan bawaan
          </button>
          {custom.length > 0 && (
            <button
              type="button"
              onClick={() => {
                clearCustom();
                setNotice("Soal buatan dihapus.");
              }}
              className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-bad-soft px-3 text-sm font-medium text-bad"
            >
              <Trash2 className="size-4" />
              Hapus soal buatan
            </button>
          )}
        </div>
      </section>

      {draft && (
        <Editor
          draft={draft}
          error={error}
          onChange={setDraft}
          onClose={() => setDraft(null)}
          onSave={save}
        />
      )}

      {pendingDelete && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-4 sm:items-center">
          <div role="dialog" aria-modal="true" className="w-full max-w-md rounded-2xl bg-surface p-6 shadow-lg">
            <h3 className="text-lg font-semibold">Hapus soal ini?</h3>
            <p className="mt-2 text-sm text-muted">
              {isBankId(pendingDelete)
                ? "Soal bawaan disembunyikan. Kamu bisa memulihkannya nanti."
                : "Soal buatan akan terhapus dari perangkat ini."}
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button type="button" onClick={() => setPendingDelete(null)} className="min-h-11 rounded-xl bg-bg px-4 text-sm font-medium">
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteQuestion(pendingDelete);
                  setPendingDelete(null);
                  setDraft((d) => (d?.id === pendingDelete ? null : d));
                }}
                className="min-h-11 rounded-xl bg-bad px-4 text-sm font-semibold text-primary-ink"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Toggle({ on, label, onClick }: { on: boolean; label: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} aria-pressed={on} className="inline-flex min-h-11 items-center gap-3 text-left">
      <span className={cn("flex h-6 w-11 items-center rounded-full p-0.5", on ? "bg-primary" : "bg-line")}>
        <span className={cn("size-5 rounded-full bg-surface transition", on && "translate-x-5")} />
      </span>
      {label}
    </button>
  );
}

function IconButton({ label, onClick, children }: { label: string; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" aria-label={label} onClick={onClick} className="inline-flex size-11 items-center justify-center rounded-xl text-muted hover:bg-bg hover:text-ink">
      {children}
    </button>
  );
}

function Editor({
  draft,
  error,
  onChange,
  onClose,
  onSave,
}: {
  draft: Question;
  error: string;
  onChange: (q: Question) => void;
  onClose: () => void;
  onSave: () => void;
}) {
  function setType(type: QType) {
    if (draft.type === type) return;
    const next = blank(type);
    onChange({ ...next, id: draft.id, topic: draft.topic, prompt: draft.prompt, discussion: draft.discussion });
  }

  function patchChoice(id: string, text: string) {
    onChange({ ...draft, choices: draft.choices.map((c) => (c.id === id ? { ...c, text } : c)) });
  }

  function mark(id: string) {
    if (draft.type === "single") onChange({ ...draft, answerIds: [id] });
    else {
      const has = draft.answerIds.includes(id);
      onChange({
        ...draft,
        answerIds: has ? draft.answerIds.filter((x) => x !== id) : [...draft.answerIds, id],
      });
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-0 sm:items-center sm:p-4">
      <div role="dialog" aria-modal="true" aria-labelledby="editor-title" className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-2xl bg-surface p-5 shadow-lg sm:rounded-2xl sm:p-6">
        <div className="mb-4 flex items-start justify-between gap-3">
          <h3 id="editor-title" className="font-display text-2xl font-semibold">
            {isBankId(draft.id) || useQuizStore.getState().custom.some((c) => c.id === draft.id) ? "Sunting soal" : "Soal baru"}
          </h3>
          <button type="button" aria-label="Tutup" onClick={onClose} className="inline-flex size-11 items-center justify-center rounded-xl hover:bg-bg">
            <X className="size-5" />
          </button>
        </div>
        <div className="mb-4 flex flex-wrap gap-2">
          {(["single", "complex", "truefalse"] as const).map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => setType(type)}
              className={cn(
                "min-h-11 rounded-full px-3 text-sm font-medium",
                draft.type === type ? "bg-primary text-primary-ink" : "bg-bg text-ink",
              )}
            >
              {TYPE_LABEL[type]}
            </button>
          ))}
        </div>
        <label className="mb-3 block text-sm font-medium">
          Topik
          <input className={cn(field, "mt-1")} value={draft.topic} onChange={(e) => onChange({ ...draft, topic: e.target.value })} />
        </label>
        <label className="mb-3 block text-sm font-medium">
          Pertanyaan
          <textarea
            rows={5}
            className={cn(field, "mt-1")}
            value={draft.prompt}
            onChange={(e) => onChange({ ...draft, prompt: e.target.value })}
          />
        </label>
        {draft.type === "truefalse" ? (
          <StatementFields
            statements={draft.statements}
            onChange={(statements) => onChange({ ...draft, statements })}
          />
        ) : (
          <ChoiceFields
            type={draft.type}
            choices={draft.choices}
            answerIds={draft.answerIds}
            onText={patchChoice}
            onMark={mark}
            onChange={(choices, answerIds) => onChange({ ...draft, choices, answerIds })}
          />
        )}
        <label className="mt-3 block text-sm font-medium">
          Pembahasan
          <textarea
            rows={4}
            className={cn(field, "mt-1")}
            value={draft.discussion}
            onChange={(e) => onChange({ ...draft, discussion: e.target.value })}
          />
        </label>
        {error && <p className="mt-3 text-sm text-bad">{error}</p>}
        <div className="mt-5 flex justify-end gap-2">
          <button type="button" onClick={onClose} className="min-h-11 rounded-xl bg-bg px-4 text-sm font-medium">
            Batal
          </button>
          <button type="button" onClick={onSave} className="min-h-11 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-ink">
            Simpan soal
          </button>
        </div>
      </div>
    </div>
  );
}

function ChoiceFields({
  type,
  choices,
  answerIds,
  onText,
  onMark,
  onChange,
}: {
  type: QType;
  choices: Choice[];
  answerIds: string[];
  onText: (id: string, text: string) => void;
  onMark: (id: string) => void;
  onChange: (choices: Choice[], answerIds: string[]) => void;
}) {
  return (
    <div className="space-y-2">
      <p className="text-sm font-medium">{type === "single" ? "Pilihan dan satu kunci" : "Pilihan dan semua kunci"}</p>
      {choices.map((choice, i) => (
        <div key={choice.id} className="flex items-center gap-2">
          <button
            type="button"
            aria-pressed={answerIds.includes(choice.id)}
            onClick={() => onMark(choice.id)}
            className={cn(
              "inline-flex size-11 shrink-0 items-center justify-center rounded-xl text-sm font-bold",
              answerIds.includes(choice.id) ? "bg-ok text-primary-ink" : "bg-bg text-muted",
            )}
          >
            {String.fromCharCode(65 + i)}
          </button>
          <input className={field} value={choice.text} onChange={(e) => onText(choice.id, e.target.value)} />
          {choices.length > 2 && (
            <button
              type="button"
              aria-label="Hapus pilihan"
              onClick={() =>
                onChange(
                  choices.filter((c) => c.id !== choice.id),
                  answerIds.filter((id) => id !== choice.id),
                )
              }
              className="inline-flex size-11 items-center justify-center rounded-xl text-muted hover:bg-bg"
            >
              <X className="size-4" />
            </button>
          )}
        </div>
      ))}
      {choices.length < 8 && (
        <button
          type="button"
          onClick={() => onChange([...choices, { id: `o${choices.length}_${Date.now().toString(36)}`, text: "" }], answerIds)}
          className="inline-flex min-h-11 items-center gap-2 text-sm font-medium text-primary"
        >
          <Plus className="size-4" />
          Tambah pilihan
        </button>
      )}
    </div>
  );
}

function StatementFields({
  statements,
  onChange,
}: {
  statements: Statement[];
  onChange: (statements: Statement[]) => void;
}) {
  return (
    <div className="space-y-2">
      <p className="text-sm font-medium">Pernyataan dan kunci benar/salah</p>
      {statements.map((statement, i) => (
        <div key={statement.id} className="rounded-xl border border-line p-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-semibold text-muted">Pernyataan {i + 1}</span>
            {statements.length > 2 && (
              <button
                type="button"
                onClick={() => onChange(statements.filter((s) => s.id !== statement.id))}
                className="text-xs font-medium text-bad"
              >
                Hapus
              </button>
            )}
          </div>
          <textarea
            rows={2}
            className={field}
            value={statement.text}
            onChange={(e) =>
              onChange(statements.map((s) => (s.id === statement.id ? { ...s, text: e.target.value } : s)))
            }
          />
          <div className="mt-2 grid grid-cols-2 gap-2">
            {[true, false].map((bit) => (
              <button
                key={String(bit)}
                type="button"
                onClick={() =>
                  onChange(statements.map((s) => (s.id === statement.id ? { ...s, answer: bit } : s)))
                }
                className={cn(
                  "min-h-11 rounded-xl text-sm font-semibold",
                  statement.answer === bit ? "bg-primary text-primary-ink" : "bg-bg text-ink",
                )}
              >
                {bit ? "Kunci: Benar" : "Kunci: Salah"}
              </button>
            ))}
          </div>
        </div>
      ))}
      {statements.length < 6 && (
        <button
          type="button"
          onClick={() =>
            onChange([...statements, { id: `s${statements.length}_${Date.now().toString(36)}`, text: "", answer: true }])
          }
          className="inline-flex min-h-11 items-center gap-2 text-sm font-medium text-primary"
        >
          <Plus className="size-4" />
          Tambah pernyataan
        </button>
      )}
    </div>
  );
}
