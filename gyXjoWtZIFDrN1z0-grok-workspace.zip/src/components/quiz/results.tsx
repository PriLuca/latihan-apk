import type { ReactNode } from "react";
import { ListChecks, RotateCcw, Trophy } from "lucide-react";
import { breakdown, formatSpent, scorePaper } from "@/lib/quiz/scoring";
import { useQuizStore } from "@/lib/quiz/store";

export function ResultsView() {
  const session = useQuizStore((s) => s.session);
  const abandon = useQuizStore((s) => s.abandon);
  const toReview = useQuizStore((s) => s.toReview);
  const score = scorePaper(session.paper, session.answers);
  const topics = breakdown(session.paper, session.answers, (q) => q.topic);
  const levels = breakdown(session.paper, session.answers, (q) => q.level ?? q.type);
  const spent =
    session.startedAt && session.submittedAt ? session.submittedAt - session.startedAt : 0;
  const name = session.studentName || "Peserta";
  const tone = score.percent >= 80 ? "Siap uji lagi dengan soal yang lebih sulit." : score.percent >= 60 ? "Pahami pembahasan pada soal yang masih salah." : "Ulangi pembahasan, lalu coba sekali lagi tanpa melihat kunci.";

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <section className="rounded-2xl border border-line bg-surface px-5 py-8 text-center shadow-sm sm:px-8">
        <div className="mx-auto flex size-20 items-center justify-center rounded-full bg-gold-soft text-gold">
          <Trophy className="size-9" />
        </div>
        <h2 className="mt-4 font-display text-3xl font-semibold tracking-tight">Ujian selesai</h2>
        <p className="mt-1 text-sm text-muted">
          {name}
          {session.expired ? " · waktu habis, jawaban yang terisi tetap dinilai" : ""}
          {spent > 0 ? ` · ${formatSpent(spent)}` : ""}
        </p>
        <div className="mt-6 grid grid-cols-3 gap-3 border-y border-line py-4">
          <Stat label="Skor" value={String(score.earned)} hint={`dari ${score.max}`} tone="text-primary" />
          <Stat label="Benar" value={String(score.correct)} hint={`dari ${score.total} soal`} tone="text-ok" />
          <Stat label="Salah" value={String(score.wrong)} hint="termasuk kosong" tone="text-bad" />
        </div>
        <p className="mx-auto mt-4 max-w-md text-sm leading-relaxed text-muted">{tone}</p>
        <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
          <button
            type="button"
            onClick={toReview}
            className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-primary px-5 text-sm font-semibold text-primary-ink"
          >
            <ListChecks className="size-4" />
            Lihat pembahasan
          </button>
          <button
            type="button"
            onClick={abandon}
            className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-bg px-5 text-sm font-semibold text-ink"
          >
            <RotateCcw className="size-4" />
            Ujian baru
          </button>
        </div>
      </section>
      <section className="grid gap-4 sm:grid-cols-2">
        <Panel title="Per tingkat">
          {levels.map((row) => (
            <Bar
              key={row.key}
              label={row.key}
              correct={row.correct}
              total={row.total}
            />
          ))}
        </Panel>
        <Panel title="Per topik">
          {topics.map((row) => (
            <Bar key={row.key} label={row.key} correct={row.correct} total={row.total} />
          ))}
        </Panel>
      </section>
    </div>
  );
}

function Stat({ label, value, hint, tone }: { label: string; value: string; hint: string; tone: string }) {
  return (
    <div className="rounded-xl bg-bg p-3">
      <span className="block text-xs text-muted">{label}</span>
      <span className={`block text-3xl font-extrabold ${tone}`}>{value}</span>
      <span className="block text-xs text-muted">{hint}</span>
    </div>
  );
}

function Panel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded-2xl border border-line bg-surface p-5 shadow-sm">
      <h3 className="mb-4 text-sm font-bold">{title}</h3>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function Bar({ label, correct, total }: { label: string; correct: number; total: number }) {
  const pct = total === 0 ? 0 : Math.round((correct / total) * 100);
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
        <span>{label}</span>
        <span className="text-xs text-muted">
          {correct}/{total}
        </span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-line">
        <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
