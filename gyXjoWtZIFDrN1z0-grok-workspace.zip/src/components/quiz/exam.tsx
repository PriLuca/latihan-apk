import { ArrowLeft, ArrowRight, Flag, Info, Send } from "lucide-react";
import { TYPE_HINT, TYPE_LABEL, TYPE_SHORT, type Question } from "@/data/questions";
import { cn } from "@/lib/cn";
import { isAnswered, isCorrect, type Answer } from "@/lib/quiz/scoring";
import { useQuizStore } from "@/lib/quiz/store";

const LETTERS = "ABCDEFGH";

function Navigator({
  paper,
  index,
  answers,
  flags,
  review,
}: {
  paper: Question[];
  index: number;
  answers: Record<string, Answer>;
  flags: string[];
  review: boolean;
}) {
  const goTo = useQuizStore((s) => s.goTo);
  return (
    <div className="grid grid-cols-5 gap-2">
      {paper.map((q, i) => {
        const answered = isAnswered(q, answers[q.id]);
        const flagged = flags.includes(q.id);
        const current = i === index;
        const skipped = review && q.graded === false;
        const correct = review && !skipped && isCorrect(q, answers[q.id]);
        const wrong = review && !skipped && !isCorrect(q, answers[q.id]);
        return (
          <button
            key={q.id}
            type="button"
            aria-label={`Soal ${i + 1}`}
            aria-current={current ? "true" : undefined}
            onClick={() => goTo(i)}
            className={cn(
              "flex size-11 items-center justify-center rounded-lg text-sm font-semibold transition",
              current && "bg-primary text-primary-ink",
              !current && skipped && "bg-line text-ink",
              !current && review && correct && "bg-ok text-primary-ink",
              !current && review && wrong && "bg-bad text-primary-ink",
              !current && !review && flagged && "bg-gold text-primary-ink",
              !current && !review && !flagged && answered && "bg-ok text-primary-ink",
              !current && !review && !flagged && !answered && "bg-line text-ink",
            )}
          >
            {i + 1}
          </button>
        );
      })}
    </div>
  );
}

function Legend({ review }: { review: boolean }) {
  const items = review
    ? [
        ["bg-primary", "Posisi aktif"],
        ["bg-ok", "Jawaban benar"],
        ["bg-bad", "Jawaban salah"],
      ]
    : [
        ["bg-primary", "Posisi aktif"],
        ["bg-ok", "Sudah dijawab"],
        ["bg-gold", "Ragu-ragu"],
        ["bg-line", "Belum dijawab"],
      ];
  return (
    <div className="space-y-2 border-t border-line pt-4 text-xs text-muted">
      {items.map(([swatch, label]) => (
        <div key={label} className="flex items-center gap-2">
          <span className={cn("inline-block size-3 rounded", swatch)} />
          {label}
        </div>
      ))}
    </div>
  );
}

function ChoiceList({ q, review }: { q: Question; review: boolean }) {
  const answer = useQuizStore((s) => s.session.answers[q.id]);
  const pickChoice = useQuizStore((s) => s.pickChoice);
  const selected = answer?.kind === "choice" ? answer.ids : [];
  return (
    <div className="space-y-3" role={q.type === "single" ? "radiogroup" : "group"}>
      {q.choices.map((choice, i) => {
        const on = selected.includes(choice.id);
        const key = q.answerIds.includes(choice.id);
        const showOk = review && key;
        const showBad = review && on && !key;
        return (
          <button
            key={choice.id}
            type="button"
            disabled={review}
            aria-pressed={on}
            onClick={() => pickChoice(q.id, choice.id, q.type)}
            className={cn(
              "flex w-full items-start gap-3 rounded-xl border px-4 py-3 text-left transition",
              !review && on && "border-primary bg-primary-soft",
              !review && !on && "border-line bg-surface hover:border-primary",
              showOk && "border-ok bg-ok-soft",
              showBad && "border-bad bg-bad-soft",
              review && !showOk && !showBad && "border-line bg-surface",
            )}
          >
            <span
              className={cn(
                "mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold",
                showOk && "bg-ok text-primary-ink",
                showBad && "bg-bad text-primary-ink",
                !showOk && !showBad && on && "bg-primary text-primary-ink",
                !showOk && !showBad && !on && "bg-primary-soft text-primary",
              )}
            >
              {LETTERS[i] ?? i + 1}
            </span>
            <span className="text-sm leading-relaxed">{choice.text}</span>
          </button>
        );
      })}
    </div>
  );
}

function StatementList({ q, review }: { q: Question; review: boolean }) {
  const answer = useQuizStore((s) => s.session.answers[q.id]);
  const pickTf = useQuizStore((s) => s.pickTf);
  const values = answer?.kind === "tf" ? answer.values : {};
  return (
    <div className="space-y-3">
      {q.statements.map((statement, i) => {
        const value = values[statement.id];
        const picked = typeof value === "boolean";
        return (
          <div key={statement.id} className="rounded-xl border border-line bg-surface p-4">
            <p className="text-sm leading-relaxed">
              <span className="mr-2 font-semibold text-primary">{i + 1}.</span>
              {statement.text}
            </p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              {[true, false].map((bit) => {
                const on = value === bit;
                const isKey = statement.answer === bit;
                const showOk = review && isKey;
                const showBad = review && on && !isKey;
                return (
                  <button
                    key={String(bit)}
                    type="button"
                    disabled={review}
                    aria-pressed={on}
                    onClick={() => pickTf(q.id, statement.id, bit)}
                    className={cn(
                      "min-h-11 rounded-xl border text-sm font-semibold transition",
                      !review && on && "border-primary bg-primary text-primary-ink",
                      !review && !on && "border-line bg-bg text-ink",
                      showOk && "border-ok bg-ok text-primary-ink",
                      showBad && "border-bad bg-bad text-primary-ink",
                      review && !showOk && !showBad && "border-line bg-bg text-muted",
                    )}
                  >
                    {bit ? "Benar" : "Salah"}
                  </button>
                );
              })}
            </div>
            {review && picked && value !== statement.answer && (
              <p className="mt-2 text-xs font-medium text-bad">
                Kunci: {statement.answer ? "Benar" : "Salah"}
              </p>
            )}
          </div>
        );
      })}
    </div>
  );
}

export function ExamView({ onRequestSubmit }: { onRequestSubmit: () => void }) {
  const paper = useQuizStore((s) => s.session.paper);
  const index = useQuizStore((s) => s.session.index);
  const phase = useQuizStore((s) => s.session.phase);
  const answers = useQuizStore((s) => s.session.answers);
  const flags = useQuizStore((s) => s.session.flags);
  const goTo = useQuizStore((s) => s.goTo);
  const toggleFlag = useQuizStore((s) => s.toggleFlag);
  const toResults = useQuizStore((s) => s.toResults);
  const q = paper[index];
  const review = phase === "review";
  if (!q) return null;
  const answeredCount = paper.filter((item) => isAnswered(item, answers[item.id])).length;
  const atLast = index >= paper.length - 1;
  const flagged = flags.includes(q.id);

  return (
    <div className="grid gap-6 lg:grid-cols-4">
      <article className="flex flex-col rounded-2xl border border-line border-l-4 border-l-gold bg-surface p-5 shadow-sm sm:p-8 lg:col-span-3">
        <div>
          <div className="mb-4 flex items-center justify-between gap-3 border-b border-line pb-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-primary-soft px-3 py-1 text-xs font-semibold tracking-wide text-primary uppercase">
                Soal {index + 1} dari {paper.length}
              </span>
              <span className="rounded-full bg-gold-soft px-3 py-1 text-xs font-semibold text-gold">
                {q.level ? `${q.level} · ${q.points ?? 1} poin` : `${TYPE_SHORT[q.type]} · ${q.topic}`}
              </span>
              {q.level && (
                <span className="rounded-full bg-primary-soft px-3 py-1 text-xs font-semibold text-primary">
                  {q.topic}
                </span>
              )}
            </div>
            {!review && (
              <button
                type="button"
                onClick={() => toggleFlag(q.id)}
                className={cn(
                  "inline-flex min-h-11 items-center gap-1.5 text-sm font-medium",
                  flagged ? "text-gold" : "text-muted hover:text-gold",
                )}
              >
                <Flag className={cn("size-4", flagged && "fill-current")} />
                {flagged ? "Ditandai" : "Ragu-ragu"}
              </button>
            )}
          </div>
          <h2 className="mb-2 text-lg leading-relaxed font-semibold whitespace-pre-wrap sm:text-xl">
            {q.prompt}
          </h2>
          <p className="mb-5 text-sm text-muted">{TYPE_HINT[q.type]}</p>
          {q.type === "truefalse" ? (
            <StatementList q={q} review={review} />
          ) : (
            <ChoiceList q={q} review={review} />
          )}
          {review && (
            <div className="mt-6 rounded-xl border border-gold bg-gold-soft p-4">
              <h3 className="mb-1 flex items-center gap-2 text-sm font-bold text-gold">
                <Info className="size-4" />
                Pembahasan
                <span
                  className={cn(
                    "ml-auto text-xs",
                    q.graded === false ? "text-muted" : isCorrect(q, answers[q.id]) ? "text-ok" : "text-bad",
                  )}
                >
                  {q.graded === false ? "Tidak dinilai" : isCorrect(q, answers[q.id]) ? "Benar" : "Salah"}
                </span>
              </h3>
              <p className="text-sm leading-relaxed text-ink">{q.discussion}</p>
            </div>
          )}
        </div>
        <div className="mt-6 flex items-center justify-between gap-3 border-t border-line pt-6">
          <button
            type="button"
            onClick={() => goTo(index - 1)}
            disabled={index === 0}
            className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-bg px-4 text-sm font-medium text-ink disabled:opacity-40"
          >
            <ArrowLeft className="size-4" />
            Sebelumnya
          </button>
          <p className="hidden text-xs text-muted sm:block">
            {review ? TYPE_LABEL[q.type] : `${answeredCount} dijawab`}
          </p>
          <button
            type="button"
            onClick={() => {
              if (!atLast) goTo(index + 1);
              else if (review) toResults();
              else onRequestSubmit();
            }}
            className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-ink"
          >
            {atLast ? (review ? "Ke hasil" : "Kirim ujian") : "Selanjutnya"}
            {atLast && !review ? <Send className="size-4" /> : <ArrowRight className="size-4" />}
          </button>
        </div>
      </article>
      <aside className="h-fit rounded-2xl border border-line bg-surface p-5 shadow-sm lg:sticky lg:top-24">
        <h3 className="mb-3 text-sm font-bold">Nomor soal</h3>
        <Navigator paper={paper} index={index} answers={answers} flags={flags} review={review} />
        <Legend review={review} />
        {!review && (
          <button
            type="button"
            onClick={onRequestSubmit}
            className="mt-6 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-ok text-sm font-semibold text-primary-ink"
          >
            <Send className="size-4" />
            Selesai & kirim
          </button>
        )}
      </aside>
    </div>
  );
}
