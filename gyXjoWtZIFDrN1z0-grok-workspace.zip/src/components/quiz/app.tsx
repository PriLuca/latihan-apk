import { Clock, GraduationCap, PenLine, SlidersHorizontal } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { TYPE_LABEL, type QType } from "@/data/questions";
import { cn } from "@/lib/cn";
import { formatClock, isAnswered } from "@/lib/quiz/scoring";
import { activeQuestions, useQuizStore } from "@/lib/quiz/store";
import { BuilderView } from "@/components/quiz/builder";
import { ExamView } from "@/components/quiz/exam";
import { ResultsView } from "@/components/quiz/results";

export function QuizApp() {
  useEffect(() => {
    void useQuizStore.persist.rehydrate();
  }, []);

  return (
    <Shell>
      <AppBody />
    </Shell>
  );
}

function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-bg text-ink">
      <Header />
      <main className="mx-auto w-full max-w-6xl px-4 py-6">{children}</main>
    </div>
  );
}

function Header() {
  const screen = useQuizStore((s) => s.screen);
  const setScreen = useQuizStore((s) => s.setScreen);
  const phase = useQuizStore((s) => s.session.phase);
  return (
    <header className="sticky top-0 z-30 border-b border-primary bg-primary text-primary-ink">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex size-11 items-center justify-center rounded-xl bg-primary-ink/15">
            <GraduationCap className="size-6 text-gold-soft" />
          </div>
          <div>
            <h1 className="font-display text-xl leading-none font-semibold">Latihan PKN</h1>
            <p className="mt-1 text-xs text-primary-ink/80">Pendidikan Kewarganegaraan</p>
          </div>
        </div>
        <div className="flex gap-2">
          <NavButton active={screen === "exam"} onClick={() => setScreen("exam")}>
            <PenLine className="size-4" />
            Mode ujian
          </NavButton>
          <NavButton active={screen === "builder"} onClick={() => setScreen("builder")}>
            <SlidersHorizontal className="size-4" />
            Kelola soal
          </NavButton>
        </div>
      </div>
      {screen === "exam" && (phase === "running" || phase === "review") && <TimerRow />}
    </header>
  );
}

function NavButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl px-3 text-sm font-semibold sm:flex-none",
        active ? "bg-primary-ink text-primary" : "bg-primary-ink/15 text-primary-ink",
      )}
    >
      {children}
    </button>
  );
}

function TimerRow() {
  const phase = useQuizStore((s) => s.session.phase);
  const endsAt = useQuizStore((s) => s.session.endsAt);
  const paper = useQuizStore((s) => s.session.paper);
  const index = useQuizStore((s) => s.session.index);
  const submit = useQuizStore((s) => s.submit);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (phase !== "running") return;
    const id = window.setInterval(() => {
      const next = Date.now();
      setNow(next);
      const end = useQuizStore.getState().session.endsAt;
      if (useQuizStore.getState().session.phase === "running" && end && next >= end) {
        useQuizStore.getState().submit(true);
      }
    }, 250);
    return () => window.clearInterval(id);
  }, [phase, submit]);

  const remain = endsAt ? Math.max(0, Math.ceil((endsAt - now) / 1000)) : 0;
  const urgent = phase === "running" && remain <= 5 * 60;
  return (
    <div className="border-t border-primary-ink/15">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-2">
        <p className="text-sm text-primary-ink/85">
          {phase === "review" ? "Pembahasan" : `Soal ${Math.min(index + 1, paper.length)} dari ${paper.length}`}
        </p>
        <div
          className={cn(
            "inline-flex min-h-11 items-center gap-2 rounded-xl px-3 font-mono text-base font-semibold tabular-nums",
            phase === "review" && "bg-primary-ink/15 text-primary-ink",
            phase === "running" && !urgent && "bg-gold-soft text-gold",
            urgent && "bg-bad-soft text-bad",
          )}
        >
          <Clock className="size-4" />
          {phase === "review" ? "Selesai" : formatClock(remain)}
        </div>
      </div>
    </div>
  );
}

function AppBody() {
  const screen = useQuizStore((s) => s.screen);
  const phase = useQuizStore((s) => s.session.phase);
  const [confirm, setConfirm] = useState(false);
  return (
    <>
      {screen === "builder" ? (
        <BuilderView />
      ) : phase === "ready" ? (
        <ReadyView />
      ) : phase === "result" ? (
        <ResultsView />
      ) : (
        <ExamView onRequestSubmit={() => setConfirm(true)} />
      )}
      {confirm && <ConfirmSubmit onClose={() => setConfirm(false)} />}
    </>
  );
}

function ReadyView() {
  const settings = useQuizStore((s) => s.settings);
  const overrides = useQuizStore((s) => s.overrides);
  const hidden = useQuizStore((s) => s.hidden);
  const custom = useQuizStore((s) => s.custom);
  const name = useQuizStore((s) => s.session.studentName);
  const setStudentName = useQuizStore((s) => s.setStudentName);
  const start = useQuizStore((s) => s.start);
  const questions = activeQuestions({ overrides, hidden, custom });
  const counts = (["single", "complex", "truefalse"] as const).map((type) => ({
    type,
    n: questions.filter((q) => q.type === type).length,
  }));

  return (
    <div className="grid items-start gap-6 lg:grid-cols-5">
      <section className="rounded-2xl border border-line bg-surface p-6 shadow-sm sm:p-8 lg:col-span-3">
        <p className="text-xs font-semibold tracking-widest text-gold uppercase">
          PKN · Latihan
        </p>
        <h2 className="mt-2 font-display text-3xl leading-tight font-semibold sm:text-4xl">
          {settings.title.trim() || "Latihan PKN"}
        </h2>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted">{settings.description}</p>
        <label className="mt-6 block text-sm font-medium">
          Nama peserta
          <input
            className="mt-1 w-full rounded-xl border border-line bg-bg px-3 py-2.5 text-sm"
            placeholder="Opsional, tampil di lembar hasil"
            value={name}
            maxLength={40}
            onChange={(e) => setStudentName(e.target.value)}
          />
        </label>
        <button
          type="button"
          disabled={questions.length === 0}
          onClick={start}
          className="mt-5 inline-flex min-h-11 items-center justify-center rounded-xl bg-primary px-5 text-sm font-semibold text-primary-ink disabled:opacity-40"
        >
          Mulai ujian
        </button>
        {questions.length === 0 && (
          <p className="mt-3 text-sm text-bad">Bank soal kosong. Pulihkan soal bawaan di menu kelola.</p>
        )}
      </section>
      <aside className="space-y-4 lg:col-span-2">
        <div className="rounded-2xl border border-line bg-surface p-5 shadow-sm">
          <h3 className="text-sm font-bold">Komposisi naskah</h3>
          <ul className="mt-3 space-y-2">
            {counts
              .filter((row) => row.n > 0)
              .map((row) => (
              <li key={row.type} className="flex items-center justify-between text-sm">
                <span>{TYPE_LABEL[row.type as QType]}</span>
                <span className="font-semibold">{row.n}</span>
              </li>
            ))}
            <li className="flex items-center justify-between border-t border-line pt-2 text-sm">
              <span>Durasi</span>
              <span className="font-semibold">{settings.durationMin} menit</span>
            </li>
          </ul>
        </div>
        <div className="rounded-2xl border border-line bg-surface p-5 text-sm leading-relaxed text-muted shadow-sm">
          <h3 className="mb-2 font-bold text-ink">Cara penilaian</h3>
          <ul className="list-disc space-y-2 pl-4">
            <li>Pilih satu jawaban pada setiap soal. Analisis pernyataan tetap memilih satu kombinasi A–E.</li>
            <li>Bobot: mudah 2 poin, sedang 3 poin, sukar 5 poin. Skor dijumlahkan, bukan dirata-rata per butir.</li>
            <li>Soal 6 tidak dinilai karena tidak ada pilihan yang hanya memuat pernyataan benar.</li>
            <li>Soal 21 menerima 4/13 maupun 16/52. Kunci terbuka setelah ujian dikirim.</li>
          </ul>
        </div>
      </aside>
    </div>
  );
}

function ConfirmSubmit({ onClose }: { onClose: () => void }) {
  const paper = useQuizStore((s) => s.session.paper);
  const answers = useQuizStore((s) => s.session.answers);
  const flags = useQuizStore((s) => s.session.flags);
  const submit = useQuizStore((s) => s.submit);
  const unanswered = paper.filter((q) => !isAnswered(q, answers[q.id])).length;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-4 sm:items-center">
      <div role="dialog" aria-modal="true" aria-labelledby="confirm-title" className="w-full max-w-md rounded-2xl bg-surface p-6 shadow-lg">
        <h3 id="confirm-title" className="font-display text-2xl font-semibold">
          Kirim ujian?
        </h3>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          {unanswered === 0
            ? "Semua soal sudah terisi."
            : `${unanswered} soal belum dijawab dan akan dinilai salah.`}
          {flags.length > 0 ? ` ${flags.length} soal masih ditandai ragu-ragu.` : ""} Pembahasan baru terbuka setelah dikirim.
        </p>
        <div className="mt-5 flex justify-end gap-2">
          <button type="button" onClick={onClose} className="min-h-11 rounded-xl bg-bg px-4 text-sm font-medium">
            Kembali
          </button>
          <button
            type="button"
            onClick={() => {
              submit(false);
              onClose();
            }}
            className="min-h-11 rounded-xl bg-ok px-4 text-sm font-semibold text-primary-ink"
          >
            Kirim sekarang
          </button>
        </div>
      </div>
    </div>
  );
}
