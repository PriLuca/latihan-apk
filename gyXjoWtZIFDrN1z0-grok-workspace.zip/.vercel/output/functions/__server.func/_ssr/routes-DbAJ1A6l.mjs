import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Clock, a as Trash2, c as RotateCcw, d as PenLine, f as ListChecks, g as Download, h as Flag, l as Plus, m as GraduationCap, n as Upload, o as SlidersHorizontal, p as Info, r as Trophy, s as Send, t as X, u as Pencil, v as ArrowRight, y as ArrowLeft } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DbAJ1A6l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TYPE_LABEL = {
	single: "Pilihan ganda",
	complex: "Pilihan ganda kompleks",
	truefalse: "Benar / Salah"
};
var TYPE_SHORT = {
	single: "PG",
	complex: "PGK",
	truefalse: "B/S"
};
var TYPE_HINT = {
	single: "Pilih satu jawaban yang paling tepat.",
	complex: "Pilih semua jawaban yang benar. Soal dinilai benar hanya jika pilihan lengkap dan tidak ada yang salah.",
	truefalse: "Tentukan Benar atau Salah pada setiap pernyataan. Soal dinilai benar hanya jika semua pernyataan tepat."
};
var opts = (lines) => lines.map((text, i) => ({
	id: "abcde"[i] ?? String(i),
	text
}));
function item(partial) {
	const answers = Array.isArray(partial.answer) ? partial.answer : [partial.answer];
	return {
		id: partial.id,
		type: "single",
		topic: partial.topic,
		level: partial.level,
		points: partial.points,
		prompt: partial.prompt,
		choices: opts(partial.options),
		answerIds: answers,
		statements: [],
		discussion: partial.discussion,
		anyOf: partial.anyOf,
		graded: partial.graded
	};
}
var BANK = [
	item({
		id: "m01",
		topic: "Permutasi",
		level: "Mudah",
		points: 2,
		prompt: "Banyak cara menyusun 7 buku pelajaran yang berbeda di atas sebuah rak buku adalah ...",
		options: [
			"2.520",
			"5.040",
			"7.560",
			"10.080",
			"40.320"
		],
		answer: "b",
		discussion: "Kunci: B. Susunan 7 objek berbeda adalah 7! = 7×6×5×4×3×2×1 = 5.040."
	}),
	item({
		id: "m02",
		topic: "Permutasi",
		level: "Sedang",
		points: 3,
		prompt: "Banyak susunan huruf yang berbeda dari kata \"MATEMATIKA\" adalah ...",
		options: [
			"151.200",
			"226.800",
			"453.600",
			"907.200",
			"3.628.800"
		],
		answer: "a",
		discussion: "Kunci: A. Kata MATEMATIKA terdiri dari 10 huruf: M dua, A tiga, T dua, serta E, I, dan K masing-masing satu. Banyak susunan = 10! / (2! × 3! × 2!) = 3.628.800 / 24 = 151.200."
	}),
	item({
		id: "m03",
		topic: "Permutasi",
		level: "Mudah",
		points: 2,
		prompt: "Banyak cara 6 orang duduk mengelilingi sebuah meja bundar adalah ...",
		options: [
			"60",
			"120",
			"240",
			"360",
			"720"
		],
		answer: "b",
		discussion: "Kunci: B. Permutasi siklis n orang adalah (n − 1)!. Untuk 6 orang: 5! = 120. Rotasi susunan yang sama tidak dihitung ulang."
	}),
	item({
		id: "m04",
		topic: "Permutasi",
		level: "Sedang",
		points: 3,
		prompt: "Lima orang siswa A, B, C, D, dan E akan berbaris. Jika A dan B harus selalu berdampingan, banyak cara mereka berbaris adalah ...",
		options: [
			"24",
			"48",
			"60",
			"120",
			"240"
		],
		answer: "b",
		discussion: "Kunci: B. A dan B dijadikan satu satuan, sehingga ada 4 satuan yang disusun: 4! cara. A dan B sendiri dapat bertukar tempat (AB atau BA), jadi 4! × 2 = 48."
	}),
	item({
		id: "m05",
		topic: "Permutasi",
		level: "Sukar",
		points: 5,
		prompt: "Tujuh orang duduk mengelilingi meja bundar. Jika dua orang tertentu harus duduk berdampingan, banyak cara duduk mereka adalah ...",
		options: [
			"120",
			"240",
			"360",
			"480",
			"720"
		],
		answer: "b",
		discussion: "Kunci: B. Dua orang yang harus berdampingan dijadikan satu satuan. Tersisa 6 satuan pada lingkaran: (6 − 1)! = 120. Kedua orang itu dapat bertukar sisi, jadi 120 × 2 = 240."
	}),
	item({
		id: "m06",
		topic: "Kombinasi",
		level: "Sedang",
		points: 3,
		graded: false,
		prompt: "Perhatikan pernyataan berikut terkait kombinasi dan permutasi!\n\n(1) Nilai C(8,3) = 56\n(2) C(n,r) = C(n, n−r)\n(3) P(n,r) selalu lebih besar dari C(n,r) untuk 0 < r < n\n(4) C(10,2) = P(10,2)\n\nPernyataan yang BENAR adalah ...",
		options: [
			"(1), (2), dan (3)",
			"(1) dan (3)",
			"(2) dan (4)",
			"(1), (2), dan (4)",
			"(1), (2), (3), dan (4)"
		],
		answer: [],
		discussion: "Soal ini tidak dinilai. Pernyataan (1) benar karena C(8,3) = 56. Pernyataan (2) benar sebagai sifat kombinasi. Pernyataan (3) salah: saat r = 1, P(n,1) = C(n,1), jadi tidak selalu lebih besar. Pernyataan (4) salah karena C(10,2) = 45 dan P(10,2) = 90. Kombinasi yang tepat hanya (1) dan (2), tetapi pilihan itu tidak tersedia."
	}),
	item({
		id: "m07",
		topic: "Kombinasi",
		level: "Mudah",
		points: 2,
		prompt: "Diketahui beberapa nilai kombinasi berikut:\n\n(1) C(5,0) = 1\n(2) C(6,1) = 6\n(3) C(7,7) = 0\n(4) C(4,2) = 6\n\nPernyataan yang BENAR adalah ...",
		options: [
			"(1), (2), dan (3)",
			"(1), (2), dan (4)",
			"(2) dan (3)",
			"(1) dan (4)",
			"semua benar"
		],
		answer: "b",
		discussion: "Kunci: B. C(5,0) = 1, C(6,1) = 6, dan C(4,2) = 6, semuanya benar. C(7,7) = 1, bukan 0, jadi pernyataan (3) salah. Yang benar adalah (1), (2), dan (4)."
	}),
	item({
		id: "m08",
		topic: "Kombinasi",
		level: "Sedang",
		points: 3,
		prompt: "Dalam sebuah kantong terdapat 5 bola merah, 4 bola biru, dan 3 bola hijau. Banyak cara mengambil 3 bola yang terdiri dari paling sedikit 1 bola merah adalah ...",
		options: [
			"165",
			"185",
			"210",
			"220",
			"286"
		],
		answer: "b",
		discussion: "Kunci: B. Total bola 12. Semua cara mengambil 3 bola dikurangi cara tanpa bola merah: C(12,3) − C(7,3) = 220 − 35 = 185. Pemeriksaan: 1 merah 105 cara, 2 merah 70 cara, 3 merah 10 cara. Jumlahnya 185."
	}),
	item({
		id: "m09",
		topic: "Kombinasi",
		level: "Sedang",
		points: 3,
		prompt: "Sebuah ujian terdiri dari 10 soal. Seorang siswa wajib mengerjakan tepat 7 soal. Banyak cara memilih soal yang akan dikerjakan adalah ...",
		options: [
			"120",
			"210",
			"360",
			"720",
			"5.040"
		],
		answer: "a",
		discussion: "Kunci: A. Urutan pemilihan tidak penting, jadi C(10,7) = C(10,3) = 120."
	}),
	item({
		id: "m10",
		topic: "Kombinasi",
		level: "Sedang",
		points: 3,
		prompt: "Dari 8 titik pada bidang datar, tidak ada 3 titik yang segaris. Banyak segitiga yang dapat dibentuk adalah ...",
		options: [
			"28",
			"56",
			"70",
			"84",
			"112"
		],
		answer: "b",
		discussion: "Kunci: B. Tiga titik menentukan satu segitiga. Banyaknya C(8,3) = 56."
	}),
	item({
		id: "m11",
		topic: "Peluang",
		level: "Mudah",
		points: 2,
		prompt: "Sebuah dadu dilantunkan sekali. Peluang munculnya mata dadu lebih dari 4 adalah ...",
		options: [
			"1/6",
			"1/3",
			"1/2",
			"2/3",
			"5/6"
		],
		answer: "b",
		discussion: "Kunci: B. Mata lebih dari 4 adalah 5 dan 6, yaitu 2 dari 6 hasil. Peluangnya 2/6 = 1/3."
	}),
	item({
		id: "m12",
		topic: "Peluang",
		level: "Mudah",
		points: 2,
		prompt: "Dalam sebuah kotak terdapat 4 bola merah dan 6 bola putih. Jika diambil satu bola secara acak, peluang terambil bola putih adalah ...",
		options: [
			"1/5",
			"2/5",
			"3/5",
			"2/3",
			"3/4"
		],
		answer: "c",
		discussion: "Kunci: C. Ada 6 bola putih dari 10 bola. Peluangnya 6/10 = 3/5."
	}),
	item({
		id: "m13",
		topic: "Peluang",
		level: "Mudah",
		points: 2,
		prompt: "Sebuah koin dilantunkan 80 kali. Frekuensi harapan munculnya sisi gambar adalah ...",
		options: [
			"20",
			"30",
			"40",
			"50",
			"60"
		],
		answer: "c",
		discussion: "Kunci: C. Peluang gambar pada koin seimbang adalah 1/2. Frekuensi harapan = 80 × 1/2 = 40."
	}),
	item({
		id: "m14",
		topic: "Peluang",
		level: "Mudah",
		points: 2,
		prompt: "Peluang seorang siswa hadir di sekolah adalah 0,85. Jika dalam sebulan terdapat 20 hari efektif sekolah, frekuensi harapan kehadiran siswa tersebut adalah ...",
		options: [
			"15",
			"16",
			"17",
			"18",
			"19"
		],
		answer: "c",
		discussion: "Kunci: C. Frekuensi harapan = 0,85 × 20 = 17 hari."
	}),
	item({
		id: "m15",
		topic: "Peluang",
		level: "Mudah",
		points: 2,
		prompt: "Dua kejadian A dan B dikatakan saling lepas jika ...",
		options: [
			"A ∩ B = ∅",
			"A ∪ B = S",
			"P(A ∩ B) = P(A)·P(B)",
			"P(A|B) = P(A)",
			"A ⊂ B"
		],
		answer: "a",
		discussion: "Kunci: A. Saling lepas berarti kedua kejadian tidak dapat terjadi bersamaan, jadi irisannya kosong. Opsi C dan D adalah ciri kejadian saling bebas, bukan saling lepas."
	}),
	item({
		id: "m16",
		topic: "Peluang",
		level: "Mudah",
		points: 2,
		prompt: "Dari bilangan 1 sampai 10 dipilih satu bilangan secara acak. Jika A = kejadian muncul bilangan genap dan B = kejadian muncul bilangan ganjil, maka hubungan A dan B adalah ...",
		options: [
			"saling lepas dan saling bebas",
			"saling lepas tetapi tidak saling bebas",
			"saling bebas tetapi tidak saling lepas",
			"tidak saling lepas dan tidak saling bebas",
			"saling bebas dan P(A ∪ B) = 1"
		],
		answer: "b",
		discussion: "Kunci: B. Genap dan ganjil tidak mungkin muncul bersama, jadi saling lepas dan P(A ∩ B) = 0. Keduanya tidak saling bebas karena P(A)P(B) = 1/4, bukan 0."
	}),
	item({
		id: "m17",
		topic: "Peluang",
		level: "Sedang",
		points: 3,
		prompt: "Dua dadu dilantunkan bersamaan. Peluang munculnya jumlah mata dadu sama dengan 7 adalah ...",
		options: [
			"1/12",
			"1/9",
			"1/6",
			"5/36",
			"7/36"
		],
		answer: "c",
		discussion: "Kunci: C. Hasil yang jumlahnya 7: (1,6), (2,5), (3,4), (4,3), (5,2), dan (6,1), yaitu 6 dari 36 hasil. Peluangnya 6/36 = 1/6."
	}),
	item({
		id: "m18",
		topic: "Peluang",
		level: "Mudah",
		points: 2,
		prompt: "Dari 200 barang yang diproduksi, 8 di antaranya cacat. Jika diambil 50 barang, frekuensi harapan barang cacat adalah ...",
		options: [
			"1",
			"2",
			"3",
			"4",
			"5"
		],
		answer: "b",
		discussion: "Kunci: B. Peluang cacat = 8/200 = 0,04. Frekuensi harapan pada 50 barang = 50 × 0,04 = 2."
	}),
	item({
		id: "m19",
		topic: "Peluang",
		level: "Sedang",
		points: 3,
		prompt: "Peluang seorang siswa lulus ujian matematika adalah 0,7 dan lulus ujian fisika adalah 0,6. Peluang lulus keduanya adalah 0,5. Peluang siswa tersebut lulus paling sedikit satu mata pelajaran adalah ...",
		options: [
			"0,6",
			"0,7",
			"0,8",
			"0,9",
			"1,0"
		],
		answer: "c",
		discussion: "Kunci: C. Kejadiannya tidak saling lepas. P(M ∪ F) = P(M) + P(F) − P(M ∩ F) = 0,7 + 0,6 − 0,5 = 0,8."
	}),
	item({
		id: "m20",
		topic: "Peluang",
		level: "Sedang",
		points: 3,
		prompt: "Dua kejadian A dan B saling bebas. Jika P(A) = 0,4 dan P(B) = 0,5, maka P(A ∩ B) adalah ...",
		options: [
			"0,1",
			"0,2",
			"0,3",
			"0,4",
			"0,9"
		],
		answer: "b",
		discussion: "Kunci: B. Untuk kejadian saling bebas, P(A ∩ B) = P(A) × P(B) = 0,4 × 0,5 = 0,2."
	}),
	item({
		id: "m21",
		topic: "Peluang",
		level: "Sedang",
		points: 3,
		anyOf: true,
		prompt: "Dari satu set kartu remi (52 kartu), diambil satu kartu secara acak. Peluang terambil kartu As atau kartu hati adalah ...",
		options: [
			"4/13",
			"16/52",
			"17/52",
			"15/52",
			"1/4"
		],
		answer: ["a", "b"],
		discussion: "Kunci: A atau B, karena keduanya sama. Ada 4 As dan 13 hati, tetapi As hati terhitung dua kali, jadi 4 + 13 − 1 = 16 kartu. Peluangnya 16/52 = 4/13. Opsi 17/52 lupa mengurangi irisan, dan 1/4 = 13/52 hanya peluang hati."
	}),
	item({
		id: "m22",
		topic: "Peluang",
		level: "Sedang",
		points: 3,
		prompt: "Sebuah dadu dan sebuah koin dilantunkan secara bersamaan. Peluang munculnya mata dadu genap dan sisi gambar pada koin adalah ...",
		options: [
			"1/8",
			"1/6",
			"1/4",
			"1/3",
			"1/2"
		],
		answer: "c",
		discussion: "Kunci: C. Peluang dadu genap = 3/6 = 1/2 dan peluang gambar = 1/2. Kedua percobaan bebas, jadi peluangnya 1/2 × 1/2 = 1/4."
	}),
	item({
		id: "m23",
		topic: "Peluang",
		level: "Sukar",
		points: 5,
		prompt: "Dua siswa, Andi dan Budi, mengerjakan ujian secara independen. Peluang Andi lulus 0,8 dan Budi lulus 0,7. Perhatikan pernyataan berikut!\n\n(1) Peluang keduanya lulus = 0,56\n(2) Peluang paling sedikit satu yang lulus = 0,94\n(3) Peluang keduanya gagal = 0,06\n(4) Peluang tepat satu yang lulus = 0,38\n\nPernyataan yang BENAR adalah ...",
		options: [
			"(1), (2), dan (3)",
			"(1) dan (3)",
			"(2) dan (4)",
			"(1), (2), (3), dan (4)",
			"(1), (3), dan (4)"
		],
		answer: "d",
		discussion: "Kunci: D. Karena independen: keduanya lulus 0,8×0,7 = 0,56; keduanya gagal 0,2×0,3 = 0,06; paling sedikit satu lulus 1 − 0,06 = 0,94; tepat satu lulus 0,8×0,3 + 0,2×0,7 = 0,38. Keempat pernyataan benar."
	}),
	item({
		id: "m24",
		topic: "Peluang",
		level: "Sukar",
		points: 5,
		prompt: "Dua dadu dilantunkan. Misalkan A = kejadian muncul jumlah 7, B = kejadian muncul setidaknya satu mata 6. Perhatikan pernyataan!\n\n(1) A dan B saling lepas\n(2) P(A) = 1/6\n(3) P(A ∪ B) = P(A) + P(B) − P(A ∩ B)\n(4) A dan B saling bebas\n\nPernyataan yang BENAR adalah ...",
		options: [
			"(1) dan (2)",
			"(2) dan (3)",
			"(1), (2), dan (3)",
			"(2), (3), dan (4)",
			"(3) dan (4)"
		],
		answer: "b",
		discussion: "Kunci: B. (2) benar karena ada 6 hasil jumlah 7 dari 36, yaitu 1/6. (3) benar sebagai aturan penjumlahan. (1) salah karena (1,6) dan (6,1) termasuk A sekaligus B. (4) salah: P(A ∩ B) = 2/36 = 1/18, sedangkan P(A)P(B) = (1/6)×(11/36) = 11/216."
	}),
	item({
		id: "m25",
		topic: "Peluang",
		level: "Sukar",
		points: 5,
		prompt: "Mesin X menghasilkan 60% produk dan mesin Y 40%. Peluang produk baik dari X = 0,95 dan dari Y = 0,90. Produk diambil secara acak. Perhatikan pernyataan!\n\n(1) Peluang produk baik = 0,93\n(2) Peluang produk cacat dari mesin X = 0,03\n(3) Peluang produk cacat = 0,07\n(4) Jika diketahui produk cacat, peluang berasal dari mesin Y lebih besar dari mesin X\n\nPernyataan yang BENAR adalah ...",
		options: [
			"(1), (2), dan (3)",
			"(1) dan (3)",
			"(1), (3), dan (4)",
			"(2) dan (4)",
			"semua benar"
		],
		answer: "e",
		discussion: "Kunci: E. Peluang baik = 0,6×0,95 + 0,4×0,90 = 0,93. Peluang cacat dari X = 0,6×0,05 = 0,03. Peluang cacat seluruhnya = 0,03 + 0,4×0,10 = 0,07. Jika cacat, peluang dari Y adalah 0,04/0,07 dan dari X adalah 0,03/0,07, jadi Y lebih besar. Keempat pernyataan benar."
	})
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function isAnswered(q, answer) {
	if (!answer) return false;
	if (q.type === "truefalse") {
		if (answer.kind !== "tf") return false;
		return q.statements.every((s) => typeof answer.values[s.id] === "boolean");
	}
	return answer.kind === "choice" && answer.ids.length > 0;
}
function isCorrect(q, answer) {
	if (q.graded === false) return false;
	if (!isAnswered(q, answer) || !answer) return false;
	if (q.type === "truefalse") {
		if (answer.kind !== "tf") return false;
		return q.statements.every((s) => answer.values[s.id] === s.answer);
	}
	if (answer.kind !== "choice") return false;
	if (q.anyOf) return answer.ids.length === 1 && q.answerIds.includes(answer.ids[0] ?? "");
	const want = [...q.answerIds].sort();
	const got = [...answer.ids].sort();
	if (want.length !== got.length) return false;
	return want.every((id, i) => id === got[i]);
}
function scorePaper(paper, answers) {
	let earned = 0;
	let max = 0;
	let correct = 0;
	let wrong = 0;
	for (const q of paper) {
		if (q.graded === false) continue;
		const pts = q.points ?? 1;
		max += pts;
		if (isCorrect(q, answers[q.id])) {
			earned += pts;
			correct += 1;
		} else wrong += 1;
	}
	const total = correct + wrong;
	const percent = max === 0 ? 0 : Math.round(earned / max * 100);
	return {
		correct,
		wrong,
		total,
		percent,
		earned,
		max
	};
}
function breakdown(paper, answers, keyOf) {
	const order = [];
	const map = /* @__PURE__ */ new Map();
	for (const q of paper) {
		if (q.graded === false) continue;
		const key = keyOf(q);
		if (!map.has(key)) {
			map.set(key, {
				correct: 0,
				total: 0
			});
			order.push(key);
		}
		const row = map.get(key);
		row.total += 1;
		if (isCorrect(q, answers[q.id])) row.correct += 1;
	}
	return order.map((key) => ({
		key,
		...map.get(key)
	}));
}
function formatClock(totalSeconds) {
	const s = Math.max(0, Math.floor(totalSeconds));
	const m = Math.floor(s / 60);
	const r = s % 60;
	return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}
function formatSpent(ms) {
	const s = Math.max(0, Math.round(ms / 1e3));
	const m = Math.floor(s / 60);
	const r = s % 60;
	if (m <= 0) return `${r} detik`;
	return `${m} menit ${r} detik`;
}
function shuffle(list) {
	const arr = list.slice();
	for (let i = arr.length - 1; i > 0; i -= 1) {
		const j = Math.floor(Math.random() * (i + 1));
		const tmp = arr[i];
		arr[i] = arr[j];
		arr[j] = tmp;
	}
	return arr;
}
var defaultSettings = {
	title: "ASAS Matematika XII",
	description: "25 soal permutasi, kombinasi, dan peluang. Mudah 2 poin, sedang 3, sukar 5.",
	durationMin: 60,
	shuffleQuestions: false,
	shuffleOptions: false
};
function emptySession(name = "") {
	return {
		phase: "ready",
		studentName: name,
		paper: [],
		index: 0,
		answers: {},
		flags: [],
		startedAt: null,
		endsAt: null,
		submittedAt: null,
		expired: false
	};
}
function clampMin(n) {
	if (!Number.isFinite(n)) return defaultSettings.durationMin;
	return Math.min(180, Math.max(1, Math.round(n)));
}
function activeQuestions(s) {
	const hidden = new Set(s.hidden);
	return [...BANK.filter((q) => !hidden.has(q.id)).map((q) => s.overrides[q.id] ?? q), ...s.custom];
}
function isBankId(id) {
	return BANK.some((q) => q.id === id);
}
var useQuizStore = create()(persist((set, get) => ({
	screen: "exam",
	settings: defaultSettings,
	overrides: {},
	hidden: [],
	custom: [],
	session: emptySession(),
	setScreen: (screen) => set({ screen }),
	setStudentName: (name) => set((s) => ({ session: {
		...s.session,
		studentName: name.slice(0, 40)
	} })),
	updateSettings: (patch) => set((s) => ({ settings: {
		...s.settings,
		...patch,
		durationMin: clampMin(patch.durationMin ?? s.settings.durationMin),
		title: (patch.title ?? s.settings.title).slice(0, 120),
		description: (patch.description ?? s.settings.description).slice(0, 240)
	} })),
	start: () => {
		const s = get();
		const source = activeQuestions(s);
		if (source.length === 0) return;
		let paper = source.map((q) => structuredClone(q));
		if (s.settings.shuffleQuestions) paper = shuffle(paper);
		if (s.settings.shuffleOptions) paper = paper.map((q) => q.type === "truefalse" ? q : {
			...q,
			choices: shuffle(q.choices)
		});
		const now = Date.now();
		set({
			screen: "exam",
			session: {
				phase: "running",
				studentName: s.session.studentName.trim(),
				paper,
				index: 0,
				answers: {},
				flags: [],
				startedAt: now,
				endsAt: now + clampMin(s.settings.durationMin) * 60 * 1e3,
				submittedAt: null,
				expired: false
			}
		});
	},
	abandon: () => set((s) => ({ session: emptySession(s.session.studentName) })),
	submit: (expired = false) => set((s) => {
		if (s.session.phase !== "running") return s;
		const now = Date.now();
		return { session: {
			...s.session,
			phase: "result",
			submittedAt: now,
			expired: expired || s.session.endsAt != null && now >= s.session.endsAt
		} };
	}),
	toReview: () => set((s) => ({
		screen: "exam",
		session: {
			...s.session,
			phase: "review",
			index: 0
		}
	})),
	toResults: () => set((s) => s.session.submittedAt ? { session: {
		...s.session,
		phase: "result"
	} } : s),
	goTo: (index) => set((s) => {
		const max = s.session.paper.length - 1;
		if (max < 0) return s;
		return { session: {
			...s.session,
			index: Math.min(max, Math.max(0, index))
		} };
	}),
	toggleFlag: (id) => set((s) => {
		if (s.session.phase !== "running") return s;
		const has = s.session.flags.includes(id);
		return { session: {
			...s.session,
			flags: has ? s.session.flags.filter((f) => f !== id) : [...s.session.flags, id]
		} };
	}),
	pickChoice: (qid, choiceId, type) => set((s) => {
		if (s.session.phase !== "running") return s;
		const prev = s.session.answers[qid];
		const ids = prev?.kind === "choice" ? prev.ids : [];
		let next;
		if (type === "single") next = ids.length === 1 && ids[0] === choiceId ? [] : [choiceId];
		else next = ids.includes(choiceId) ? ids.filter((id) => id !== choiceId) : [...ids, choiceId];
		return { session: {
			...s.session,
			answers: {
				...s.session.answers,
				[qid]: {
					kind: "choice",
					ids: next
				}
			}
		} };
	}),
	pickTf: (qid, statementId, value) => set((s) => {
		if (s.session.phase !== "running") return s;
		const prev = s.session.answers[qid];
		const values = prev?.kind === "tf" ? { ...prev.values } : {};
		if (values[statementId] === value) delete values[statementId];
		else values[statementId] = value;
		return { session: {
			...s.session,
			answers: {
				...s.session.answers,
				[qid]: {
					kind: "tf",
					values
				}
			}
		} };
	}),
	saveQuestion: (q) => set((s) => {
		if (isBankId(q.id)) return { overrides: {
			...s.overrides,
			[q.id]: q
		} };
		const idx = s.custom.findIndex((c) => c.id === q.id);
		if (idx >= 0) {
			const custom = s.custom.slice();
			custom[idx] = q;
			return { custom };
		}
		return { custom: [...s.custom, q] };
	}),
	deleteQuestion: (id) => set((s) => {
		if (isBankId(id)) {
			const overrides = { ...s.overrides };
			delete overrides[id];
			return {
				overrides,
				hidden: s.hidden.includes(id) ? s.hidden : [...s.hidden, id]
			};
		}
		return { custom: s.custom.filter((c) => c.id !== id) };
	}),
	resetBank: () => set({
		hidden: [],
		overrides: {}
	}),
	clearCustom: () => set({ custom: [] }),
	importBundle: (bundle) => set(() => ({
		settings: {
			...defaultSettings,
			...bundle.settings,
			durationMin: clampMin(bundle.settings?.durationMin ?? defaultSettings.durationMin)
		},
		overrides: bundle.overrides ?? {},
		hidden: bundle.hidden ?? [],
		custom: bundle.custom ?? []
	}))
}), {
	name: "mat-asas-v1",
	skipHydration: true,
	partialize: (s) => ({
		screen: s.screen,
		settings: s.settings,
		overrides: s.overrides,
		hidden: s.hidden,
		custom: s.custom,
		session: s.session
	})
}));
var field = "w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink placeholder:text-muted";
function blank(type) {
	const id = `c_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
	if (type === "truefalse") return {
		id,
		type,
		topic: "",
		prompt: "",
		discussion: "",
		choices: [],
		answerIds: [],
		statements: [{
			id: "s1",
			text: "",
			answer: true
		}, {
			id: "s2",
			text: "",
			answer: false
		}]
	};
	return {
		id,
		type,
		topic: "",
		prompt: "",
		discussion: "",
		statements: [],
		answerIds: ["a"],
		choices: [
			{
				id: "a",
				text: ""
			},
			{
				id: "b",
				text: ""
			},
			{
				id: "c",
				text: ""
			},
			{
				id: "d",
				text: ""
			}
		]
	};
}
function clean(q) {
	const topic = q.topic.trim();
	const prompt = q.prompt.trim();
	const discussion = q.discussion.trim();
	if (topic.length < 2) return "Topik minimal 2 karakter.";
	if (prompt.length < 10) return "Pertanyaan minimal 10 karakter.";
	if (discussion.length < 10) return "Pembahasan minimal 10 karakter.";
	if (q.type === "truefalse") {
		const statements = q.statements.map((s) => ({
			...s,
			text: s.text.trim()
		})).filter((s) => s.text).slice(0, 6);
		if (statements.length < 2) return "Isi minimal dua pernyataan.";
		return {
			...q,
			topic,
			prompt,
			discussion,
			choices: [],
			answerIds: [],
			statements
		};
	}
	const choices = q.choices.map((c) => ({
		...c,
		text: c.text.trim()
	})).filter((c) => c.text).slice(0, 8);
	if (choices.length < 2) return "Isi minimal dua pilihan.";
	const ids = new Set(choices.map((c) => c.id));
	const answerIds = q.answerIds.filter((id) => ids.has(id));
	if (q.type === "single" && answerIds.length !== 1) return "Tandai tepat satu kunci jawaban.";
	if (q.type === "complex" && answerIds.length < 1) return "Tandai minimal satu kunci jawaban.";
	return {
		...q,
		topic,
		prompt,
		discussion,
		choices,
		answerIds,
		statements: []
	};
}
function isQuestion(value) {
	if (!value || typeof value !== "object") return false;
	const q = value;
	if (typeof q.id !== "string" || q.type !== "single" && q.type !== "complex" && q.type !== "truefalse" || typeof q.prompt !== "string" || typeof q.topic !== "string" || typeof q.discussion !== "string" || !Array.isArray(q.choices) || !Array.isArray(q.answerIds) || !Array.isArray(q.statements)) return false;
	const choicesOk = q.choices.every((c) => !!c && typeof c.id === "string" && typeof c.text === "string");
	const statementsOk = q.statements.every((s) => !!s && typeof s.id === "string" && typeof s.text === "string" && typeof s.answer === "boolean");
	return choicesOk && statementsOk && q.answerIds.every((id) => typeof id === "string");
}
function BuilderView() {
	const settings = useQuizStore((s) => s.settings);
	const updateSettings = useQuizStore((s) => s.updateSettings);
	const overrides = useQuizStore((s) => s.overrides);
	const hidden = useQuizStore((s) => s.hidden);
	const custom = useQuizStore((s) => s.custom);
	const saveQuestion = useQuizStore((s) => s.saveQuestion);
	const deleteQuestion = useQuizStore((s) => s.deleteQuestion);
	const resetBank = useQuizStore((s) => s.resetBank);
	const clearCustom = useQuizStore((s) => s.clearCustom);
	const importBundle = useQuizStore((s) => s.importBundle);
	const running = useQuizStore((s) => s.session.phase === "running");
	const questions = activeQuestions({
		overrides,
		hidden,
		custom
	});
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [query, setQuery] = (0, import_react.useState)("");
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)("");
	const fileRef = (0, import_react.useRef)(null);
	const shown = questions.filter((q) => {
		if (filter === "custom" && isBankId(q.id)) return false;
		if (filter !== "all" && filter !== "custom" && q.type !== filter) return false;
		return `${q.topic} ${q.prompt}`.toLowerCase().includes(query.trim().toLowerCase());
	});
	function openNew() {
		setError("");
		setDraft(blank("single"));
	}
	function openEdit(q) {
		setError("");
		setDraft(structuredClone(q));
	}
	function save() {
		if (!draft) return;
		const result = clean(draft);
		if (typeof result === "string") {
			setError(result);
			return;
		}
		saveQuestion(result);
		setDraft(null);
		setNotice("Soal tersimpan di perangkat ini.");
	}
	function exportBank() {
		const blob = new Blob([JSON.stringify({
			version: 1,
			settings,
			overrides,
			hidden,
			custom
		}, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "bank-soal-notula.json";
		a.click();
		URL.revokeObjectURL(url);
	}
	async function onImport(file) {
		try {
			const raw = JSON.parse(await file.text());
			const bankIds = new Set(BANK.map((q) => q.id));
			const overridesNext = {};
			if (raw.overrides && typeof raw.overrides === "object") {
				for (const [id, value] of Object.entries(raw.overrides)) if (bankIds.has(id) && isQuestion(value)) overridesNext[id] = value;
			}
			const hiddenNext = Array.isArray(raw.hidden) ? raw.hidden.filter((id) => typeof id === "string" && bankIds.has(id)) : [];
			const customNext = [];
			if (Array.isArray(raw.custom)) for (const value of raw.custom) {
				if (!isQuestion(value)) continue;
				const id = bankIds.has(value.id) ? `c_${value.id}_${customNext.length}` : value.id;
				customNext.push({
					...value,
					id
				});
			}
			importBundle({
				screen: "builder",
				settings: {
					...settings,
					...raw.settings ?? {}
				},
				overrides: overridesNext,
				hidden: hiddenNext,
				custom: customNext,
				session: useQuizStore.getState().session
			});
			setNotice(`Berkas masuk: ${Object.keys(overridesNext).length} suntingan, ${customNext.length} soal buatan.`);
		} catch {
			setNotice("Berkas tidak bisa dibaca. Gunakan ekspor dari aplikasi ini.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			running && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-gold bg-gold-soft px-4 py-3 text-sm text-ink",
				children: "Ujian sedang berlangsung. Perubahan soal tidak mengubah naskah percobaan yang sudah dimulai."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-5 shadow-sm sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: "Pengaturan ujian"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium sm:col-span-2",
							children: ["Judul", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: cn(field, "mt-1"),
								value: settings.title,
								onChange: (e) => updateSettings({ title: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium sm:col-span-2",
							children: ["Deskripsi", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: cn(field, "mt-1"),
								value: settings.description,
								onChange: (e) => updateSettings({ description: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Durasi (menit)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 1,
								max: 180,
								className: cn(field, "mt-1"),
								value: settings.durationMin,
								onChange: (e) => updateSettings({ durationMin: Number(e.target.value) })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col justify-end gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								on: settings.shuffleQuestions,
								label: "Acak urutan soal",
								onClick: () => updateSettings({ shuffleQuestions: !settings.shuffleQuestions })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								on: settings.shuffleOptions,
								label: "Acak urutan pilihan",
								onClick: () => updateSettings({ shuffleOptions: !settings.shuffleOptions })
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-5 shadow-sm sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl font-semibold",
							children: "Bank soal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								questions.length,
								" soal aktif",
								hidden.length > 0 ? ` · ${hidden.length} bawaan disembunyikan` : "",
								custom.length > 0 ? ` · ${custom.length} buatan` : ""
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: openNew,
							className: "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Tambah soal"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: field,
							placeholder: "Cari topik atau potongan soal",
							value: query,
							onChange: (e) => setQuery(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								["all", "Semua"],
								["single", "PG"],
								["complex", "PGK"],
								["truefalse", "B/S"],
								["custom", "Buatan"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setFilter(id),
								className: cn("min-h-11 rounded-full px-3 text-sm font-medium", filter === id ? "bg-primary text-primary-ink" : "bg-bg text-ink"),
								children: label
							}, id))
						})]
					}),
					notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-ok",
						children: notice
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 divide-y divide-line",
						children: [shown.map((q, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 w-8 shrink-0 text-sm font-semibold text-muted",
									children: i + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-1 flex flex-wrap gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-primary-soft px-2 py-0.5 text-xs font-semibold text-primary",
												children: TYPE_SHORT[q.type]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-gold-soft px-2 py-0.5 text-xs font-semibold text-gold",
												children: q.topic
											}),
											!isBankId(q.id) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-bg px-2 py-0.5 text-xs font-semibold text-muted",
												children: "Buatan"
											}),
											overrides[q.id] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-bg px-2 py-0.5 text-xs font-semibold text-muted",
												children: "Diedit"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "line-clamp-2 text-sm leading-relaxed",
										children: q.prompt
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex shrink-0 gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
										label: "Sunting soal",
										onClick: () => openEdit(q),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
										label: "Hapus soal",
										onClick: () => setPendingDelete(q.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									})]
								})
							]
						}, q.id)), shown.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-8 text-center text-sm text-muted",
							children: "Tidak ada soal pada saringan ini."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2 border-t border-line pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: exportBank,
								className: "inline-flex min-h-11 items-center gap-2 rounded-xl bg-bg px-3 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Ekspor"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => fileRef.current?.click(),
								className: "inline-flex min-h-11 items-center gap-2 rounded-xl bg-bg px-3 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), "Impor"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								type: "file",
								accept: "application/json",
								className: "hidden",
								onChange: (e) => {
									const file = e.target.files?.[0];
									if (file) onImport(file);
									e.target.value = "";
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									resetBank();
									setNotice("Soal bawaan dikembalikan.");
								},
								className: "inline-flex min-h-11 items-center gap-2 rounded-xl bg-bg px-3 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Pulihkan bawaan"]
							}),
							custom.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									clearCustom();
									setNotice("Soal buatan dihapus.");
								},
								className: "inline-flex min-h-11 items-center gap-2 rounded-xl bg-bad-soft px-3 text-sm font-medium text-bad",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Hapus soal buatan"]
							})
						]
					})
				]
			}),
			draft && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
				draft,
				error,
				onChange: setDraft,
				onClose: () => setDraft(null),
				onSave: save
			}),
			pendingDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-4 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					className: "w-full max-w-md rounded-2xl bg-surface p-6 shadow-lg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg font-semibold",
							children: "Hapus soal ini?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: isBankId(pendingDelete) ? "Soal bawaan disembunyikan. Kamu bisa memulihkannya nanti." : "Soal buatan akan terhapus dari perangkat ini."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPendingDelete(null),
								className: "min-h-11 rounded-xl bg-bg px-4 text-sm font-medium",
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									deleteQuestion(pendingDelete);
									setPendingDelete(null);
									setDraft((d) => d?.id === pendingDelete ? null : d);
								},
								className: "min-h-11 rounded-xl bg-bad px-4 text-sm font-semibold text-primary-ink",
								children: "Hapus"
							})]
						})
					]
				})
			})
		]
	});
}
function Toggle({ on, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		"aria-pressed": on,
		className: "inline-flex min-h-11 items-center gap-3 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("flex h-6 w-11 items-center rounded-full p-0.5", on ? "bg-primary" : "bg-line"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-5 rounded-full bg-surface transition", on && "translate-x-5") })
		}), label]
	});
}
function IconButton({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "inline-flex size-11 items-center justify-center rounded-xl text-muted hover:bg-bg hover:text-ink",
		children
	});
}
function Editor({ draft, error, onChange, onClose, onSave }) {
	function setType(type) {
		if (draft.type === type) return;
		onChange({
			...blank(type),
			id: draft.id,
			topic: draft.topic,
			prompt: draft.prompt,
			discussion: draft.discussion
		});
	}
	function patchChoice(id, text) {
		onChange({
			...draft,
			choices: draft.choices.map((c) => c.id === id ? {
				...c,
				text
			} : c)
		});
	}
	function mark(id) {
		if (draft.type === "single") onChange({
			...draft,
			answerIds: [id]
		});
		else {
			const has = draft.answerIds.includes(id);
			onChange({
				...draft,
				answerIds: has ? draft.answerIds.filter((x) => x !== id) : [...draft.answerIds, id]
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-0 sm:items-center sm:p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "editor-title",
			className: "max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-2xl bg-surface p-5 shadow-lg sm:rounded-2xl sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						id: "editor-title",
						className: "font-display text-2xl font-semibold",
						children: isBankId(draft.id) || useQuizStore.getState().custom.some((c) => c.id === draft.id) ? "Sunting soal" : "Soal baru"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Tutup",
						onClick: onClose,
						className: "inline-flex size-11 items-center justify-center rounded-xl hover:bg-bg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4 flex flex-wrap gap-2",
					children: [
						"single",
						"complex",
						"truefalse"
					].map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setType(type),
						className: cn("min-h-11 rounded-full px-3 text-sm font-medium", draft.type === type ? "bg-primary text-primary-ink" : "bg-bg text-ink"),
						children: TYPE_LABEL[type]
					}, type))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mb-3 block text-sm font-medium",
					children: ["Topik", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: cn(field, "mt-1"),
						value: draft.topic,
						onChange: (e) => onChange({
							...draft,
							topic: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mb-3 block text-sm font-medium",
					children: ["Pertanyaan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 5,
						className: cn(field, "mt-1"),
						value: draft.prompt,
						onChange: (e) => onChange({
							...draft,
							prompt: e.target.value
						})
					})]
				}),
				draft.type === "truefalse" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementFields, {
					statements: draft.statements,
					onChange: (statements) => onChange({
						...draft,
						statements
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceFields, {
					type: draft.type,
					choices: draft.choices,
					answerIds: draft.answerIds,
					onText: patchChoice,
					onMark: mark,
					onChange: (choices, answerIds) => onChange({
						...draft,
						choices,
						answerIds
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 block text-sm font-medium",
					children: ["Pembahasan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 4,
						className: cn(field, "mt-1"),
						value: draft.discussion,
						onChange: (e) => onChange({
							...draft,
							discussion: e.target.value
						})
					})]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-bad",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "min-h-11 rounded-xl bg-bg px-4 text-sm font-medium",
						children: "Batal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onSave,
						className: "min-h-11 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-ink",
						children: "Simpan soal"
					})]
				})
			]
		})
	});
}
function ChoiceFields({ type, choices, answerIds, onText, onMark, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: type === "single" ? "Pilihan dan satu kunci" : "Pilihan dan semua kunci"
			}),
			choices.map((choice, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": answerIds.includes(choice.id),
						onClick: () => onMark(choice.id),
						className: cn("inline-flex size-11 shrink-0 items-center justify-center rounded-xl text-sm font-bold", answerIds.includes(choice.id) ? "bg-ok text-primary-ink" : "bg-bg text-muted"),
						children: String.fromCharCode(65 + i)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: choice.text,
						onChange: (e) => onText(choice.id, e.target.value)
					}),
					choices.length > 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Hapus pilihan",
						onClick: () => onChange(choices.filter((c) => c.id !== choice.id), answerIds.filter((id) => id !== choice.id)),
						className: "inline-flex size-11 items-center justify-center rounded-xl text-muted hover:bg-bg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})
				]
			}, choice.id)),
			choices.length < 8 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onChange([...choices, {
					id: `o${choices.length}_${Date.now().toString(36)}`,
					text: ""
				}], answerIds),
				className: "inline-flex min-h-11 items-center gap-2 text-sm font-medium text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Tambah pilihan"]
			})
		]
	});
}
function StatementFields({ statements, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Pernyataan dan kunci benar/salah"
			}),
			statements.map((statement, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-semibold text-muted",
							children: ["Pernyataan ", i + 1]
						}), statements.length > 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onChange(statements.filter((s) => s.id !== statement.id)),
							className: "text-xs font-medium text-bad",
							children: "Hapus"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 2,
						className: field,
						value: statement.text,
						onChange: (e) => onChange(statements.map((s) => s.id === statement.id ? {
							...s,
							text: e.target.value
						} : s))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 grid grid-cols-2 gap-2",
						children: [true, false].map((bit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onChange(statements.map((s) => s.id === statement.id ? {
								...s,
								answer: bit
							} : s)),
							className: cn("min-h-11 rounded-xl text-sm font-semibold", statement.answer === bit ? "bg-primary text-primary-ink" : "bg-bg text-ink"),
							children: bit ? "Kunci: Benar" : "Kunci: Salah"
						}, String(bit)))
					})
				]
			}, statement.id)),
			statements.length < 6 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onChange([...statements, {
					id: `s${statements.length}_${Date.now().toString(36)}`,
					text: "",
					answer: true
				}]),
				className: "inline-flex min-h-11 items-center gap-2 text-sm font-medium text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Tambah pernyataan"]
			})
		]
	});
}
var LETTERS = "ABCDEFGH";
function Navigator({ paper, index, answers, flags, review }) {
	const goTo = useQuizStore((s) => s.goTo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-5 gap-2",
		children: paper.map((q, i) => {
			const answered = isAnswered(q, answers[q.id]);
			const flagged = flags.includes(q.id);
			const current = i === index;
			const skipped = review && q.graded === false;
			const correct = review && !skipped && isCorrect(q, answers[q.id]);
			const wrong = review && !skipped && !isCorrect(q, answers[q.id]);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": `Soal ${i + 1}`,
				"aria-current": current ? "true" : void 0,
				onClick: () => goTo(i),
				className: cn("flex size-11 items-center justify-center rounded-lg text-sm font-semibold transition", current && "bg-primary text-primary-ink", !current && skipped && "bg-line text-ink", !current && review && correct && "bg-ok text-primary-ink", !current && review && wrong && "bg-bad text-primary-ink", !current && !review && flagged && "bg-gold text-primary-ink", !current && !review && !flagged && answered && "bg-ok text-primary-ink", !current && !review && !flagged && !answered && "bg-line text-ink"),
				children: i + 1
			}, q.id);
		})
	});
}
function Legend({ review }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2 border-t border-line pt-4 text-xs text-muted",
		children: (review ? [
			["bg-primary", "Posisi aktif"],
			["bg-ok", "Jawaban benar"],
			["bg-bad", "Jawaban salah"]
		] : [
			["bg-primary", "Posisi aktif"],
			["bg-ok", "Sudah dijawab"],
			["bg-gold", "Ragu-ragu"],
			["bg-line", "Belum dijawab"]
		]).map(([swatch, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("inline-block size-3 rounded", swatch) }), label]
		}, label))
	});
}
function ChoiceList({ q, review }) {
	const answer = useQuizStore((s) => s.session.answers[q.id]);
	const pickChoice = useQuizStore((s) => s.pickChoice);
	const selected = answer?.kind === "choice" ? answer.ids : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		role: q.type === "single" ? "radiogroup" : "group",
		children: q.choices.map((choice, i) => {
			const on = selected.includes(choice.id);
			const key = q.answerIds.includes(choice.id);
			const showOk = review && key;
			const showBad = review && on && !key;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: review,
				"aria-pressed": on,
				onClick: () => pickChoice(q.id, choice.id, q.type),
				className: cn("flex w-full items-start gap-3 rounded-xl border px-4 py-3 text-left transition", !review && on && "border-primary bg-primary-soft", !review && !on && "border-line bg-surface hover:border-primary", showOk && "border-ok bg-ok-soft", showBad && "border-bad bg-bad-soft", review && !showOk && !showBad && "border-line bg-surface"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold", showOk && "bg-ok text-primary-ink", showBad && "bg-bad text-primary-ink", !showOk && !showBad && on && "bg-primary text-primary-ink", !showOk && !showBad && !on && "bg-primary-soft text-primary"),
					children: LETTERS[i] ?? i + 1
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm leading-relaxed",
					children: choice.text
				})]
			}, choice.id);
		})
	});
}
function StatementList({ q, review }) {
	const answer = useQuizStore((s) => s.session.answers[q.id]);
	const pickTf = useQuizStore((s) => s.pickTf);
	const values = answer?.kind === "tf" ? answer.values : {};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: q.statements.map((statement, i) => {
			const value = values[statement.id];
			const picked = typeof value === "boolean";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm leading-relaxed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mr-2 font-semibold text-primary",
							children: [i + 1, "."]
						}), statement.text]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [true, false].map((bit) => {
							const on = value === bit;
							const isKey = statement.answer === bit;
							const showOk = review && isKey;
							const showBad = review && on && !isKey;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: review,
								"aria-pressed": on,
								onClick: () => pickTf(q.id, statement.id, bit),
								className: cn("min-h-11 rounded-xl border text-sm font-semibold transition", !review && on && "border-primary bg-primary text-primary-ink", !review && !on && "border-line bg-bg text-ink", showOk && "border-ok bg-ok text-primary-ink", showBad && "border-bad bg-bad text-primary-ink", review && !showOk && !showBad && "border-line bg-bg text-muted"),
								children: bit ? "Benar" : "Salah"
							}, String(bit));
						})
					}),
					review && picked && value !== statement.answer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs font-medium text-bad",
						children: ["Kunci: ", statement.answer ? "Benar" : "Salah"]
					})
				]
			}, statement.id);
		})
	});
}
function ExamView({ onRequestSubmit }) {
	const paper = useQuizStore((s) => s.session.paper);
	const index = useQuizStore((s) => s.session.index);
	const phase = useQuizStore((s) => s.session.phase);
	const answers = useQuizStore((s) => s.session.answers);
	const flags = useQuizStore((s) => s.session.flags);
	const goTo = useQuizStore((s) => s.goTo);
	const toggleFlag = useQuizStore((s) => s.toggleFlag);
	const toResults = useQuizStore((s) => s.toResults);
	const q = paper[index];
	const review = phase === "review";
	if (!q) return null;
	const answeredCount = paper.filter((item) => isAnswered(item, answers[item.id])).length;
	const atLast = index >= paper.length - 1;
	const flagged = flags.includes(q.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "flex flex-col rounded-2xl border border-line border-l-4 border-l-gold bg-surface p-5 shadow-sm sm:p-8 lg:col-span-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between gap-3 border-b border-line pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full bg-primary-soft px-3 py-1 text-xs font-semibold tracking-wide text-primary uppercase",
								children: [
									"Soal ",
									index + 1,
									" dari ",
									paper.length
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-gold-soft px-3 py-1 text-xs font-semibold text-gold",
								children: q.level ? `${q.level} · ${q.points ?? 1} poin` : `${TYPE_SHORT[q.type]} · ${q.topic}`
							}),
							q.level && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-primary-soft px-3 py-1 text-xs font-semibold text-primary",
								children: q.topic
							})
						]
					}), !review && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggleFlag(q.id),
						className: cn("inline-flex min-h-11 items-center gap-1.5 text-sm font-medium", flagged ? "text-gold" : "text-muted hover:text-gold"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: cn("size-4", flagged && "fill-current") }), flagged ? "Ditandai" : "Ragu-ragu"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-lg leading-relaxed font-semibold whitespace-pre-wrap sm:text-xl",
					children: q.prompt
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-5 text-sm text-muted",
					children: TYPE_HINT[q.type]
				}),
				q.type === "truefalse" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementList, {
					q,
					review
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceList, {
					q,
					review
				}),
				review && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 rounded-xl border border-gold bg-gold-soft p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "mb-1 flex items-center gap-2 text-sm font-bold text-gold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4" }),
							"Pembahasan",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("ml-auto text-xs", q.graded === false ? "text-muted" : isCorrect(q, answers[q.id]) ? "text-ok" : "text-bad"),
								children: q.graded === false ? "Tidak dinilai" : isCorrect(q, answers[q.id]) ? "Benar" : "Salah"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-ink",
						children: q.discussion
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center justify-between gap-3 border-t border-line pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => goTo(index - 1),
						disabled: index === 0,
						className: "inline-flex min-h-11 items-center gap-2 rounded-xl bg-bg px-4 text-sm font-medium text-ink disabled:opacity-40",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Sebelumnya"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-xs text-muted sm:block",
						children: review ? TYPE_LABEL[q.type] : `${answeredCount} dijawab`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							if (!atLast) goTo(index + 1);
							else if (review) toResults();
							else onRequestSubmit();
						},
						className: "inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-ink",
						children: [atLast ? review ? "Ke hasil" : "Kirim ujian" : "Selanjutnya", atLast && !review ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "h-fit rounded-2xl border border-line bg-surface p-5 shadow-sm lg:sticky lg:top-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-3 text-sm font-bold",
					children: "Nomor soal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigator, {
					paper,
					index,
					answers,
					flags,
					review
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { review }),
				!review && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onRequestSubmit,
					className: "mt-6 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-ok text-sm font-semibold text-primary-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }), "Selesai & kirim"]
				})
			]
		})]
	});
}
function ResultsView() {
	const session = useQuizStore((s) => s.session);
	const abandon = useQuizStore((s) => s.abandon);
	const toReview = useQuizStore((s) => s.toReview);
	const score = scorePaper(session.paper, session.answers);
	const topics = breakdown(session.paper, session.answers, (q) => q.topic);
	const levels = breakdown(session.paper, session.answers, (q) => q.level ?? q.type);
	const spent = session.startedAt && session.submittedAt ? session.submittedAt - session.startedAt : 0;
	const name = session.studentName || "Peserta";
	const tone = score.percent >= 80 ? "Siap uji lagi dengan soal yang lebih sulit." : score.percent >= 60 ? "Pahami pembahasan pada soal yang masih salah." : "Ulangi pembahasan, lalu coba sekali lagi tanpa melihat kunci.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-2xl border border-line bg-surface px-5 py-8 text-center shadow-sm sm:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex size-20 items-center justify-center rounded-full bg-gold-soft text-gold",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-9" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 font-display text-3xl font-semibold tracking-tight",
					children: "Ujian selesai"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						name,
						session.expired ? " · waktu habis, jawaban yang terisi tetap dinilai" : "",
						spent > 0 ? ` · ${formatSpent(spent)}` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid grid-cols-3 gap-3 border-y border-line py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Skor",
							value: String(score.earned),
							hint: `dari ${score.max}`,
							tone: "text-primary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Benar",
							value: String(score.correct),
							hint: `dari ${score.total} soal`,
							tone: "text-ok"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Salah",
							value: String(score.wrong),
							hint: "termasuk kosong",
							tone: "text-bad"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-4 max-w-md text-sm leading-relaxed text-muted",
					children: tone
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col justify-center gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: toReview,
						className: "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-primary px-5 text-sm font-semibold text-primary-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "size-4" }), "Lihat pembahasan"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: abandon,
						className: "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-bg px-5 text-sm font-semibold text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Ujian baru"]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid gap-4 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Per tingkat",
				children: levels.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					label: row.key,
					correct: row.correct,
					total: row.total
				}, row.key))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Per topik",
				children: topics.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					label: row.key,
					correct: row.correct,
					total: row.total
				}, row.key))
			})]
		})]
	});
}
function Stat({ label, value, hint, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-bg p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `block text-3xl font-extrabold ${tone}`,
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-muted",
				children: hint
			})
		]
	});
}
function Panel({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-surface p-5 shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mb-4 text-sm font-bold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children
		})]
	});
}
function Bar({ label, correct, total }) {
	const pct = total === 0 ? 0 : Math.round(correct / total * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex items-baseline justify-between gap-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-xs text-muted",
			children: [
				correct,
				"/",
				total
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 overflow-hidden rounded-full bg-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full rounded-full bg-primary",
			style: { width: `${pct}%` }
		})
	})] });
}
function QuizApp() {
	(0, import_react.useEffect)(() => {
		useQuizStore.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBody, {}) });
}
function Shell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto w-full max-w-6xl px-4 py-6",
			children
		})]
	});
}
function Header() {
	const screen = useQuizStore((s) => s.screen);
	const setScreen = useQuizStore((s) => s.setScreen);
	const phase = useQuizStore((s) => s.session.phase);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 border-b border-primary bg-primary text-primary-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-6xl flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-11 items-center justify-center rounded-xl bg-primary-ink/15",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-6 text-gold-soft" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-xl leading-none font-semibold",
					children: "ASAS Matematika"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-primary-ink/80",
					children: "Kelas XII · Permutasi, Kombinasi, Peluang"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavButton, {
					active: screen === "exam",
					onClick: () => setScreen("exam"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-4" }), "Mode ujian"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavButton, {
					active: screen === "builder",
					onClick: () => setScreen("builder"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-4" }), "Kelola soal"]
				})]
			})]
		}), screen === "exam" && (phase === "running" || phase === "review") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimerRow, {})]
	});
}
function NavButton({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl px-3 text-sm font-semibold sm:flex-none", active ? "bg-primary-ink text-primary" : "bg-primary-ink/15 text-primary-ink"),
		children
	});
}
function TimerRow() {
	const phase = useQuizStore((s) => s.session.phase);
	const endsAt = useQuizStore((s) => s.session.endsAt);
	const paper = useQuizStore((s) => s.session.paper);
	const index = useQuizStore((s) => s.session.index);
	const submit = useQuizStore((s) => s.submit);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		if (phase !== "running") return;
		const id = window.setInterval(() => {
			const next = Date.now();
			setNow(next);
			const end = useQuizStore.getState().session.endsAt;
			if (useQuizStore.getState().session.phase === "running" && end && next >= end) useQuizStore.getState().submit(true);
		}, 250);
		return () => window.clearInterval(id);
	}, [phase, submit]);
	const remain = endsAt ? Math.max(0, Math.ceil((endsAt - now) / 1e3)) : 0;
	const urgent = phase === "running" && remain <= 300;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-t border-primary-ink/15",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-primary-ink/85",
				children: phase === "review" ? "Pembahasan" : `Soal ${Math.min(index + 1, paper.length)} dari ${paper.length}`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("inline-flex min-h-11 items-center gap-2 rounded-xl px-3 font-mono text-base font-semibold tabular-nums", phase === "review" && "bg-primary-ink/15 text-primary-ink", phase === "running" && !urgent && "bg-gold-soft text-gold", urgent && "bg-bad-soft text-bad"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" }), phase === "review" ? "Selesai" : formatClock(remain)]
			})]
		})
	});
}
function AppBody() {
	const screen = useQuizStore((s) => s.screen);
	const phase = useQuizStore((s) => s.session.phase);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [screen === "builder" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuilderView, {}) : phase === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadyView, {}) : phase === "result" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsView, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExamView, { onRequestSubmit: () => setConfirm(true) }), confirm && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSubmit, { onClose: () => setConfirm(false) })] });
}
function ReadyView() {
	const settings = useQuizStore((s) => s.settings);
	const overrides = useQuizStore((s) => s.overrides);
	const hidden = useQuizStore((s) => s.hidden);
	const custom = useQuizStore((s) => s.custom);
	const name = useQuizStore((s) => s.session.studentName);
	const setStudentName = useQuizStore((s) => s.setStudentName);
	const start = useQuizStore((s) => s.start);
	const questions = activeQuestions({
		overrides,
		hidden,
		custom
	});
	const counts = [
		"single",
		"complex",
		"truefalse"
	].map((type) => ({
		type,
		n: questions.filter((q) => q.type === type).length
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid items-start gap-6 lg:grid-cols-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-2xl border border-line bg-surface p-6 shadow-sm sm:p-8 lg:col-span-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-gold uppercase",
					children: "Matematika XII · ASAS"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-3xl leading-tight font-semibold sm:text-4xl",
					children: settings.title.trim() || "ASAS Matematika XII"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xl text-sm leading-relaxed text-muted",
					children: settings.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-6 block text-sm font-medium",
					children: ["Nama peserta", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-xl border border-line bg-bg px-3 py-2.5 text-sm",
						placeholder: "Opsional, tampil di lembar hasil",
						value: name,
						maxLength: 40,
						onChange: (e) => setStudentName(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: questions.length === 0,
					onClick: start,
					className: "mt-5 inline-flex min-h-11 items-center justify-center rounded-xl bg-primary px-5 text-sm font-semibold text-primary-ink disabled:opacity-40",
					children: "Mulai ujian"
				}),
				questions.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-bad",
					children: "Bank soal kosong. Pulihkan soal bawaan di menu kelola."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "space-y-4 lg:col-span-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-line bg-surface p-5 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-bold",
					children: "Komposisi naskah"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2",
					children: [counts.filter((row) => row.n > 0).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: TYPE_LABEL[row.type] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: row.n
						})]
					}, row.type)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between border-t border-line pt-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Durasi" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold",
							children: [settings.durationMin, " menit"]
						})]
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-line bg-surface p-5 text-sm leading-relaxed text-muted shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 font-bold text-ink",
					children: "Cara penilaian"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "list-disc space-y-2 pl-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Pilih satu jawaban pada setiap soal. Analisis pernyataan tetap memilih satu kombinasi A–E." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Bobot: mudah 2 poin, sedang 3 poin, sukar 5 poin. Skor dijumlahkan, bukan dirata-rata per butir." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Soal 6 tidak dinilai karena tidak ada pilihan yang hanya memuat pernyataan benar." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Soal 21 menerima 4/13 maupun 16/52. Kunci terbuka setelah ujian dikirim." })
					]
				})]
			})]
		})]
	});
}
function ConfirmSubmit({ onClose }) {
	const paper = useQuizStore((s) => s.session.paper);
	const answers = useQuizStore((s) => s.session.answers);
	const flags = useQuizStore((s) => s.session.flags);
	const submit = useQuizStore((s) => s.submit);
	const unanswered = paper.filter((q) => !isAnswered(q, answers[q.id])).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-4 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "confirm-title",
			className: "w-full max-w-md rounded-2xl bg-surface p-6 shadow-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					id: "confirm-title",
					className: "font-display text-2xl font-semibold",
					children: "Kirim ujian?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: [
						unanswered === 0 ? "Semua soal sudah terisi." : `${unanswered} soal belum dijawab dan akan dinilai salah.`,
						flags.length > 0 ? ` ${flags.length} soal masih ditandai ragu-ragu.` : "",
						" Pembahasan baru terbuka setelah dikirim."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "min-h-11 rounded-xl bg-bg px-4 text-sm font-medium",
						children: "Kembali"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							submit(false);
							onClose();
						},
						className: "min-h-11 rounded-xl bg-ok px-4 text-sm font-semibold text-primary-ink",
						children: "Kirim sekarang"
					})]
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizApp, {});
}
//#endregion
export { Home as component };
