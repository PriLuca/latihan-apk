//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BJIcDbp1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BcPbMoxr.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BcPbMoxr.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CPWr6O4v.js"]
	}
} });
//#endregion
export { tsrStartManifest };
